from PyQt4 import uic
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from spec_routines import specread
from mca_routines import mcaread
from mplwidget import MplWidget
from matplotlib.widgets import MultiCursor
from TwoDDetector import TwoDDetector
from scipy.optimize import leastsq
import pylab as pl
import numpy as np
import time
import os
import sys

(Ui_MainWindow, QMainWindow) = uic.loadUiType('mainwindow.ui')

class MainWindow (QMainWindow):
    """MainWindow inherits QMainWindow"""

    def __init__ (self, parent = None):
        QMainWindow.__init__(self, parent)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.pilatus=TwoDDetector('Pilatus')
        self.bruker=TwoDDetector('Bruker')
        np.seterr(invalid='ignore',divide='ignore')
        self.mcaDirName='vortex'
        self.ccdDirName='apex'
        self.pilDirName='pilatus'
        self.beamline='APS-15IDC'
        self.specData={}
        self.specPar={}
        self.startLineNum=0
        self.refData=[]
        self.refInfo=[]
        self.refQc=float(self.ui.refQcLineEdit.text())
        self.absfac=float(self.ui.AbsFacLineEdit.text())
        self.reffiles=[]
        self.selectedBgFrameNums=[]
        self.selectedreffiles_rows=[]
        self.ui.PlotWidget.setCurrentIndex(0)
        self.directory=os.getcwd()
        self.pilGIDshow=0
        self.cutDirItems=['H Cut', 'V Cut', 'Qz Cut', 'Qxy Cut']
        self.connect(self.ui.actionAbout, SIGNAL('triggered()'),self.showAbout)
        self.connect(self.ui.actionOpen_Spec_File, SIGNAL('triggered()'),self.openSpecFile)
        self.connect(self.ui.speUpSpeFilePushButton, SIGNAL('clicked()'),self.readSpecFile)
        self.connect(self.ui.actionAPS_15IDC, SIGNAL('triggered()'),self.selectAPS_15IDC)
        self.connect(self.ui.actionAPS_9IDC, SIGNAL('triggered()'),self.selectAPS_9IDC)
        self.connect(self.ui.actionG_l2, SIGNAL('triggered()'), self.calg_l2)
        self.connect(self.ui.actionG_l3, SIGNAL('triggered()'), self.calg_l3)
        self.connect(self.ui.actionAbs_ratio, SIGNAL('triggered()'), self.calabsrat)
        self.connect(self.ui.scanListWidget, SIGNAL('itemSelectionChanged()'),self.scanListChanged)
       # self.connect(self.ui.scanListWidget, SIGNAL('itemClicked(QListWidgetItem*)'),self.scanListChanged)
        self.connect(self.ui.spLogXCheckBox, SIGNAL('stateChanged(int)'),self.updateSpecPlotData)
        self.connect(self.ui.spLogYCheckBox, SIGNAL('stateChanged(int)'),self.updateSpecPlotData)
        self.connect(self.ui.spGridCheckBox, SIGNAL('stateChanged(int)'),self.updateSpecPlotData)
        self.connect(self.ui.spLegendCheckBox, SIGNAL('stateChanged(int)'),self.updateSpecPlotData)
        self.connect(self.ui.spNCheckBox, SIGNAL('stateChanged(int)'),self.updateSpecPlotData)
        self.connect(self.ui.spLegendLocComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
        self.connect(self.ui.spXComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
        self.connect(self.ui.spYComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
        self.connect(self.ui.spNComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
        self.connect(self.ui.scansLineEdit, SIGNAL('returnPressed()'),self.scanListInputChanged)
        self.connect(self.ui.imageListWidget, SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged)        
        self.connect(self.ui.mcaLogXCheckBox, SIGNAL('stateChanged(int)'),self.updateMcaPlotData)
        self.connect(self.ui.mcaLogYCheckBox, SIGNAL('stateChanged(int)'),self.updateMcaPlotData)
        self.connect(self.ui.mcaGridCheckBox, SIGNAL('stateChanged(int)'),self.updateMcaPlotData)
        self.connect(self.ui.mcaLegendCheckBox, SIGNAL('stateChanged(int)'),self.updateMcaPlotData)
        self.connect(self.ui.mcaNormCheckBox, SIGNAL('stateChanged(int)'),self.updateMcaPlotData)
        self.connect(self.ui.mcaLegendLocComboBox, SIGNAL('currentIndexChanged(int)'),self.updateMcaPlotData)
        self.connect(self.ui.mcaCalibCheckBox, SIGNAL('stateChanged(int)'),self.updateMcaPlotData)
        self.connect(self.ui.mcaCalibConLineEdit, SIGNAL('returnPressed()'),self.updateMcaPlotData)
        self.connect(self.ui.mcaCalibLinLineEdit, SIGNAL('returnPressed()'),self.updateMcaPlotData)
        self.connect(self.ui.mcaCalibQuaLineEdit, SIGNAL('returnPressed()'),self.updateMcaPlotData)
        self.connect(self.ui.gixSumCheckBox,SIGNAL('stateChanged(int)'),self.update2dPlots)
        self.connect(self.ui.gixBPCfacLineEdit,SIGNAL('returnPressed()'),self.imageSelectedScanChanged)
        self.connect(self.ui.pilBPCfacLineEdit,SIGNAL('returnPressed()'),self.imageSelectedScanChanged)
        self.connect(self.ui.gixLogIntCheckBox, SIGNAL('stateChanged(int)'),self.update2dPlots)
        self.connect(self.ui.pilLogIntCheckBox, SIGNAL('stateChanged(int)'),self.update2dPlots)
        self.connect(self.ui.imageSelectAllCheckBox, SIGNAL('clicked()'),self.selectAllImages)
        self.connect(self.ui.imageListWidget, SIGNAL('clicked(QModelIndex)'),self.unSelectedAllImages)
        self.connect(self.ui.gixSpecCheckBox,SIGNAL('stateChanged(int)'),self.update2dPlots)
        self.connect(self.ui.gixCcd_OffLineEdit,SIGNAL('returnPressed()'),self.update2dPlots)
        self.connect(self.ui.gixCMapComboBox, SIGNAL('currentIndexChanged(int)'), self.update2dPlots)
        self.connect(self.ui.gixMinLineEdit, SIGNAL('returnPressed()'),self.update2dPlots)
        self.connect(self.ui.gixMaxLineEdit, SIGNAL('returnPressed()'),self.update2dPlots)
        self.connect(self.ui.gixAxesComboBox, SIGNAL('currentIndexChanged(int)'), self.update2dPlots)
        self.connect(self.ui.gixMinHorizontalSlider, SIGNAL('sliderReleased()'),self.updateMinSlider)
        self.connect(self.ui.gixMaxHorizontalSlider, SIGNAL('sliderReleased()'),self.updateMaxSlider)
        self.connect(self.ui.pilSpecCheckBox,SIGNAL('stateChanged(int)'),self.update2dPlots)
        self.connect(self.ui.pilCMapComboBox, SIGNAL('currentIndexChanged(int)'), self.update2dPlots)
        self.connect(self.ui.pilMinLineEdit, SIGNAL('returnPressed()'),self.update2dPlots)
        self.connect(self.ui.pilMaxLineEdit, SIGNAL('returnPressed()'),self.update2dPlots)
        self.connect(self.ui.pilAxesComboBox, SIGNAL('currentIndexChanged(int)'), self.update2dPlots)
        self.connect(self.ui.pilMinHorizontalSlider, SIGNAL('sliderReleased()'),self.updatePilMinSlider)
        self.connect(self.ui.pilMaxHorizontalSlider, SIGNAL('sliderReleased()'),self.updatePilMaxSlider)
        self.connect(self.ui.gixRefPushButton,SIGNAL('clicked()'),self.refPlotWin)
        self.connect(self.ui.pilRefPushButton,SIGNAL('clicked()'),self.refPlotWin)
        self.connect(self.ui.gixDBPosLineEdit,SIGNAL('returnPressed()'),self.update2dPlots)
        self.connect(self.ui.gixSDDistLineEdit,SIGNAL('returnPressed()'),self.update2dPlots)
        self.connect(self.ui.refSlitLineEdit,SIGNAL('returnPressed()'),self.refQzListSelectionChanged)
        self.connect(self.ui.refBGOffLineEdit,SIGNAL('returnPressed()'),self.refQzListSelectionChanged)
        self.connect(self.ui.refQzListWidget, SIGNAL('itemSelectionChanged()'),self.refQzListSelectionChanged)
        self.connect(self.ui.refBGDirComboBox,SIGNAL('currentIndexChanged(int)'),self.refQzListSelectionChanged)
        self.connect(self.ui.refAnalyzePushButton,SIGNAL('clicked()'),self.refAnalyze)
        self.connect(self.ui.refBPCFacLineEdit, SIGNAL('returnPressed()'),self.refAnalyze)
        #self.connect(self.ui.AbsFacLineEdit, SIGNAL('returnPressed()'),self.refDoBPC)
        self.connect(self.ui.refAcceptPushButton, SIGNAL('clicked()'), self.updateRefDataList)
        self.connect(self.ui.refAnalyzeAllPushButton, SIGNAL('clicked()'),self.refAnalyzeAll)
        #self.connect(self.ui.refDataListWidget,SIGNAL('itemChanged(QListWidgetItem*)'), self.updateRefPlotData)
        self.connect(self.ui.refQcLineEdit,SIGNAL('returnPressed()'),self.updateRefPlotData)
        self.connect(self.ui.refQoffLineEdit,SIGNAL('returnPressed()'),self.updateRefPlotData)
        self.connect(self.ui.refRRFCheckBox,SIGNAL('stateChanged(int)'),self.updateRefPlotData)
        self.connect(self.ui.refLogYCheckBox,SIGNAL('stateChanged(int)'),self.updateRefPlotData)
        self.connect(self.ui.refQzSqrCheckBox,SIGNAL('stateChanged(int)'),self.updateRefPlotData)
        self.connect(self.ui.refDelPushButton,SIGNAL('clicked()'),self.delRefDataList)
        self.connect(self.ui.refSeaWinLineEdit, SIGNAL('returnPressed()'),self.refAnalyze)
        self.connect(self.ui.refExportPushButton,SIGNAL('clicked()'), self.saveRefData)
        self.connect(self.ui.refAddFilePushButton, SIGNAL('clicked()'), self.addRefFiles)
        self.connect(self.ui.refRemoveFilePushButton, SIGNAL('clicked()'), self.removeRefFiles)
        self.connect(self.ui.refRefFileListWidget, SIGNAL('itemSelectionChanged()'), self.updateSelectedRefFiles)
        self.connect(self.ui.refLegendCheckBox,SIGNAL('stateChanged(int)'), self.updateRefPlotData)
        self.connect(self.ui.refLegendLocComboBox,SIGNAL('currentIndexChanged(int)'), self.updateRefPlotData)
        #self.connect(self.ui.refCenCheckBox, SIGNAL('stateChanged(int)'),)
        self.connect(self.ui.refCenLineEdit, SIGNAL('returnPressed()'), self.refAnalyze)
        self.connect(self.ui.gixLineAreaPushButton, SIGNAL('clicked()'), self.updateCutData)
        self.connect(self.ui.gixIntRangeLineEdit, SIGNAL('returnPressed()'), self.updateCutData)
        self.connect(self.ui.pilLineAreaPushButton, SIGNAL('clicked()'), self.updateCutData)
        self.connect(self.ui.pilIntRangeLineEdit, SIGNAL('returnPressed()'), self.updateCutData)
        #self.connect(self.ui.gixCutDirComboBox, SIGNAL('currentIndexChanged(int)'), self.updateCutData)
        self.connect(self.ui.cutLogXCheckBox, SIGNAL('stateChanged(int)'),self.updateCutData)
        self.connect(self.ui.cutLogYCheckBox, SIGNAL('stateChanged(int)'),self.updateCutPlotData)
        self.connect(self.ui.cutGridCheckBox, SIGNAL('stateChanged(int)'),self.updateCutPlotData)
        self.connect(self.ui.cutLegendCheckBox, SIGNAL('stateChanged(int)'),self.updateCutData)
        self.connect(self.ui.cutLegendLocComboBox, SIGNAL('currentIndexChanged(int)'),self.updateCutData)
        self.connect(self.ui.cutErrorbarCheckBox, SIGNAL('stateChanged(int)'),self.updateCutData)
        self.connect(self.ui.cutExportPushButton, SIGNAL('clicked()'),self.saveCutData)
        self.connect(self.ui.cutOffsetCheckBox, SIGNAL('stateChanged(int)'),self.updateCutData)
        self.connect(self.ui.cutOffsetLineEdit, SIGNAL('returnPressed()'),self.updateCutData)
        self.connect(self.ui.mcaExportPushButton, SIGNAL('clicked()'),self.saveMcaData)
        self.connect(self.ui.mcaOffsetCheckBox, SIGNAL('stateChanged(int)'),self.updateMcaPlotData)
        self.connect(self.ui.mcaOffsetLineEdit, SIGNAL('returnPressed()'),self.updateMcaPlotData)
        self.connect(self.ui.cutClearGraphPushButton, SIGNAL('clicked()'),self.clearCutGraph)
        self.connect(self.ui.backgroundPushButton, SIGNAL('clicked()'),self.addBGImagestoList)
        self.connect(self.ui.removePushButton, SIGNAL('clicked()'), self.removeBGImages)
        self.connect(self.ui.backgroundListWidget, SIGNAL('itemSelectionChanged()'),self.bgSelectionChanged)
        self.connect(self.ui.bgSelectAllCheckBox, SIGNAL('stateChanged(int)'),self.bgSelectAll)
        self.connect(self.ui.bgFacLineEdit, SIGNAL('returnPressed()'),self.ccdSelectedScanChanged)
        self.connect(self.ui.scanListWidget, SIGNAL('doubleClicked(QModelIndex)'),self.displayScanInfo)
        self.connect(self.ui.pilGIDPushButton, SIGNAL('clicked()'),self.pilGIDPlot)
        self.connect(self.ui.refNormFacCheckBox, SIGNAL('stateChanged(int)'),self.updateRefPlotData)
        
        
        
    def selectAPS_15IDC(self):
        self.ui.statusBar.clearMessage()
        self.beamline='APS-15IDC'
        self.ui.actionAPS_9IDC.setChecked(False)
        self.ui.statusBar.showMessage('APS-15IDC Selected')
    
    def selectAPS_9IDC(self):
        self.ui.statusBar.clearMessage()
        self.beamline='APS-9IDC'
        self.ui.actionAPS_15IDC.setChecked(False)
        self.ui.statusBar.showMessage('APS-9IDC Selected')
        
    def showAbout(self):
        cwd=os.getcwd()
        files=['mainwindow.py','mainwindow.ui','main.py','mca_routines.py','mpl2dwidget.py','mplwidget.py','spec_routines.py','TwoDDetector.py','logo.png']
        fname=[cwd+'/'+fname for fname in files]
        updateTime=max([os.path.getmtime(fn) for fn in fname])
        self.messageBox('MW-XReader\n Version: 0.1.2012\nLast Update: '+time.strftime("%m/%d/%Y %I:%M:%S %p",time.localtime(updateTime))+'\nDevelopers:\n\tWei Bu <weibu1977@gmail.com>\n\tMrinal K Bera <nayanbera@gmail.com>',title='About')
        
    def openSpecFile(self):
        self.ui.statusBar.clearMessage()       
        self.ui.imagesLabel.setText('Detector:')
        self.specFileName=QFileDialog.getOpenFileName(caption='Open Spec File')
        if self.specFileName!='':
            self.clearAll()
            self.directory=str(QFileInfo(self.specFileName).absolutePath())
            self.directory_old=self.directory
        else:
            self.directory=self.directory_old
        specData_old=self.specData
        specPar_old=self.specPar
        startLineNum_old=self.startLineNum
        try:
            self.specData={}
            self.specPar={}
            self.startLineNum=0
            self.readSpecFile()
            self.ui.specFileLabel.setText('SpecFile: '+str(self.specFileName.split('/')[-1]))
        except:
            self.specData=specData_old
            self.specPar=specPar_old
            self.startLineNum=startLineNum_old
            print "Either you have just loaded the old file or there is something wrong with Specfile reading"

        
    def clearAll(self):
        self.disconnect(self.ui.scanListWidget, SIGNAL('itemSelectionChanged()'),self.scanListChanged)
        self.disconnect(self.ui.imageListWidget, SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged) 
        self.disconnect(self.ui.refQzListWidget, SIGNAL('itemSelectionChanged()'),self.refQzListSelectionChanged)
        self.disconnect(self.ui.spXComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
        self.disconnect(self.ui.spYComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
        self.disconnect(self.ui.spNComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
        self.ui.imageListWidget.clear()
        self.ui.statusBar.clearMessage()
        self.ui.scanListWidget.clear()
        self.ui.specPlotMplWidget.canvas.ax.clear()
        self.ui.spXComboBox.clear()
        self.ui.spYComboBox.clear()
        self.ui.spNComboBox.clear()
        self.ui.mcaPlotMplWidget.canvas.ax.clear()
        self.ui.mcaPlotMplWidget.canvas.draw()
        self.ui.refBadPixListWidget.clear()
        self.ui.cutPlotMplWidget.canvas.ax.clear()
        self.ui.cutPlotMplWidget.canvas.draw()
        self.ui.gixMplWidget.canvas.ax.clear()
        self.ui.gixMplWidget.canvas.draw()
        self.ui.refADDataPlotWidget.canvas.ax.clear()
        self.ui.refADDataPlotWidget.canvas.draw()
        self.ui.refQzListWidget.clear() 
        self.connect(self.ui.scanListWidget, SIGNAL('itemSelectionChanged()'),self.scanListChanged)
        self.connect(self.ui.imageListWidget, SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged) 
        self.connect(self.ui.refQzListWidget, SIGNAL('itemSelectionChanged()'),self.refQzListSelectionChanged)
        self.connect(self.ui.spXComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
        self.connect(self.ui.spYComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
        self.connect(self.ui.spNComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
         
        
    def readSpecFile(self):
        '''
        Reading spec File
        '''
        self.specRead=specread(self.specFileName,startLineNum=self.startLineNum, beamline=self.beamline,data=self.specData,par=self.specPar)
        self.clearAll()
        self.startLineNum=self.specRead.endLineNum
        self.specData=self.specRead.Data
        self.specPar=self.specRead.Par
        if self.specData['NumOfScans']==0:
            self.ui.statusBar.showMessage(self.SpecData['Message'])
        else:
            if self.specData['Error']:
                self.messageBox('Warning:: The spec file has identical scan numbers!!')
            self.scanlines=[self.specData[i]['ScanLine'] for i in range(1,self.specData['NumOfScans']+1)]
            self.ui.scanListWidget.addItems(self.scanlines)
            if np.any([self.specPar[i]['Detector']=='Vortex' for i in range(1,self.specData['NumOfScans']+1)]):
                if QDir(self.directory+'/'+self.mcaDirName).exists()==True:
                    self.mcaDir=self.directory+'/'+self.mcaDirName
                else:
                    self.messageBox('Warning:: The default MCA directory not found, please choose!!')
                    self.mcaDir=QFileDialog.getExistingDirectory(caption='Open MCA Directory')
                self.mcafhead=str(self.mcaDir)+'/'+self.specFileName.split('/')[-1]+'_'
                self.mcaftail='_mca' 
                print "MCA data Found!!"
            if np.any([self.specPar[i]['Detector']=='Bruker' for i in range(1,self.specData['NumOfScans']+1)]):
                if QDir(self.directory+'/'+self.ccdDirName).exists()==True:
                    self.ccdDir=self.directory+'/'+self.ccdDirName
                else:
                    self.messageBox('Warning:: The default CCD directory not found, please choose!!')
                    self.ccdDir=QFileDialog.getExistingDirectory(caption='Open CCD Directory')
                self.ccdfhead=str(self.ccdDir)+'/'+self.specFileName.split('/')[-1]+'_SCAN-'
                self.ccdftail='.sfrm'
                print "Bruker Images Found!!"
            if np.any([self.specPar[i]['Detector']=='Pilatus' for i in range(1,self.specData['NumOfScans']+1)]):
                if QDir(self.directory+'/'+self.pilDirName).exists()==True:
                    self.pilDir=self.directory+'/'+self.pilDirName
                else:
                    self.messageBox('Warning:: The default Piltus directory not found, please choose!!')
                    self.pilDir=QFileDialog.getExistingDirectory(caption='Open Pilatus Directory')
                self.pilfhead=str(self.pilDir)+'/'+self.specFileName.split('/')[-1]+'_SCAN-'
                self.pilftail='.tif'
                print "Pilatus Images Found!!"
        self.ui.statusBar.showMessage('Done')
        self.scanCenter={}


    def scanListChanged(self):
        self.ui.statusBar.clearMessage()
        self.ui.imageSelectAllCheckBox.setCheckState(0)
        self.ui.imageListWidget.clear()
        self.disconnect(self.ui.spXComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
        self.disconnect(self.ui.spYComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
        self.disconnect(self.ui.spNComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
        self.selectedScans=self.ui.scanListWidget.selectedItems()
        #self.selectedScanNums=[self.ui.scanListWidget.row(items) for items in self.selectedScans]
        self.selectedScanNums=[int(str(items.text()).split()[1]) for items in self.selectedScans]
        self.ui.scansLineEdit.setText(str([item for item in self.selectedScanNums])[1:-1])
        if self.checkSameScans()==False or self.selectedScanNums==[]:
            self.ui.statusBar.showMessage('Error:: The scans are not identical or some scans have no data!!')
            self.disconnect(self.ui.scanListWidget, SIGNAL('itemSelectionChanged()'),self.scanListChanged)
            for item in self.selectedScans:
                self.ui.scanListWidget.setItemSelected(item,False)
            self.connect(self.ui.scanListWidget, SIGNAL('itemSelectionChanged()'),self.scanListChanged)
            self.ui.specPlotMplWidget.canvas.ax.clear()
            self.ui.specPlotMplWidget.canvas.draw()
        else:
            self.ui.spXComboBox.clear()
            self.ui.spYComboBox.clear()
            self.ui.spNComboBox.clear()
            self.ui.spXComboBox.addItems(self.specData[self.selectedScanNums[0]]['ScanVar'])
            self.ui.spYComboBox.addItems(self.specData[self.selectedScanNums[0]]['ScanVar'])
            ycol=self.ui.spYComboBox.findText(self.specData['YCol'])
            if ycol>0:
                self.ui.spYComboBox.setCurrentIndex(self.ui.spYComboBox.findText(self.specData['YCol']))
            else:
                self.ui.spYComboBox.setCurrentIndex(len(self.specData[self.selectedScanNums[0]]['ScanVar'])-1)
            self.ui.spNComboBox.addItems(self.specData[self.selectedScanNums[0]]['ScanVar'])
            ncol=self.ui.spYComboBox.findText(self.specData['NCol'])
            if ncol>0:
                self.ui.spNComboBox.setCurrentIndex(self.ui.spNComboBox.findText(self.specData['NCol']))
            else:
                self.ui.spNComboBox.setCurrentIndex(len(self.specData[self.selectedScanNums[0]]['ScanVar'])-2)   
            self.ui.spXComboBox.setCurrentIndex(0)           
            self.connect(self.ui.spXComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
            self.connect(self.ui.spYComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
            self.connect(self.ui.spNComboBox, SIGNAL('currentIndexChanged(int)'),self.updateSpecPlotData)
            try:
                self.updateSpecPlotData()
            except:
                self.ui.statusBar.showMessage('Warning:: The scan(s) are not regular Spec scan')
            if self.specPar[self.selectedScanNums[0]]['Detector']=='Vortex':
                self.updateMcaImageList()
                self.ui.imagesLabel.setText('Vortex:')
                self.ui.PlotWidget.setCurrentIndex(0)
            if self.specPar[self.selectedScanNums[0]]['Detector']=='Bruker':
                self.updateCcdImageList()
                self.ui.PlotWidget.setCurrentIndex(0)
                self.ui.imagesLabel.setText('Bruker:')
            if self.specPar[self.selectedScanNums[0]]['Detector']=='Pilatus':
                self.updatePilImageList()
                self.ui.PlotWidget.setCurrentIndex(0)
                self.ui.imagesLabel.setText('Pilatus:')
        self.ui.statusBar.showMessage('Done')
            
    def scanListInputChanged(self):
        inputscannumbers=str(self.ui.scansLineEdit.text()).split(',')
        self.disconnect(self.ui.scanListWidget, SIGNAL('itemSelectionChanged()'),self.scanListChanged)
        try:    
            for i in self.selectedScanNums:
                self.ui.scanListWidget.setItemSelected(self.ui.scanListWidget.item(i),False)
            self.selectedScanNums=[]
        except:
            self.selectedScanNums=[]
        for item in inputscannumbers:
            scan=map(int, item.split('-'))
            if len(scan)>1:
                self.selectedScanNums=self.selectedScanNums+range(scan[0],scan[1]+1)
            else:
                self.selectedScanNums=self.selectedScanNums+scan
        #self.selectedScanNums=[item-1 for item in self.selectedScanNums]
        self.connect(self.ui.scanListWidget, SIGNAL('itemSelectionChanged()'),self.scanListChanged)
        snum=[int(item.split()[1]) for item in self.scanlines]
        for i in self.selectedScanNums:
            self.ui.scanListWidget.setItemSelected(self.ui.scanListWidget.item(snum.index(i)),True)
        self.ui.scanListWidget.setCurrentRow(self.selectedScanNums[-1]-1)
        self.ui.statusBar.showMessage('Done')
        

    def updateSpecPlotData(self):
        self.ui.statusBar.clearMessage()
        self.ui.specPlotMplWidget.canvas.ax.clear()
        self.specData['YCol']=str(self.ui.spYComboBox.currentText())
        self.specData['NCol']=str(self.ui.spNComboBox.currentText())
        if self.checkSameScans()==False:
            self.ui.statusBar.showMessage('Error:: The scans are not identical or some scans have no data!!')
        else:
            for i in self.selectedScanNums:
                x=self.specData[i][str(self.ui.spXComboBox.currentText())]
                y=self.specData[i][str(self.ui.spYComboBox.currentText())]
                n=self.specData[i][str(self.ui.spNComboBox.currentText())]
                self.label='S '+str(i+1)
                self.specPlot(x,y,n)
            yerr=pl.sqrt(np.abs(y))
            if self.ui.spNCheckBox.checkState()!=0:
                yerr=pl.sqrt(y/n**2+y**2/n**3)
                y=y/n
            try:
                self.specPeakFit(x,y,yerr)
                self.peakPos='%.4f'%x[np.argmax(y)]
                if (self.specFitPar[0]+self.specFitPar[1]/2.0)>x[0] and (self.specFitPar[0]+self.specFitPar[1]/2.0)>x[-1]:
                    self.peakCenter='%.4f'%(self.specFitPar[0]-self.specFitPar[1]/2.0)
                    self.peakFWHM='%.4f'%self.specFitPar[5]
                    #print '1', self.specFitPar[0]
                    self.ui.specPlotMplWidget.canvas.ax.set_title('Peak= '+self.peakPos+', Edge= '+self.peakCenter+', Edge Width= '+self.peakFWHM)
                elif (self.specFitPar[0]-self.specFitPar[1]/2.0)<x[0] and (self.specFitPar[0]-self.specFitPar[1]/2.0)<x[-1]:
                    self.peakCenter='%.4f'%(self.specFitPar[0]+self.specFitPar[1]/2.0)
                    self.peakFWHM='%.4f'%self.specFitPar[5]
                    #print '2', self.specFitPar[0]
                    self.ui.specPlotMplWidget.canvas.ax.set_title('Peak= '+self.peakPos+', Edge= '+self.peakCenter+', Edge Width= '+self.peakFWHM)
                else:    
                    self.peakCenter='%.4f'%self.specFitPar[0]
                    self.peakFWHM='%.4f'%self.specFitPar[1]
                    #print '3', self.specFitPar[0]
                    self.ui.specPlotMplWidget.canvas.ax.set_title('Peak= '+self.peakPos+', Cen= '+self.peakCenter+', FWHM= '+self.peakFWHM)
                if self.specFitPar[7]<1:
                    self.ui.specPlotMplWidget.canvas.ax.plot(x,self.specPeakFun1(self.specFitPar, x),'g--',label='Fit')
                else:
                    self.ui.specPlotMplWidget.canvas.ax.plot(x,self.specPeakFun2(self.specFitPar, x),'g--',label='Fit')
                self.scanCenter[self.selectedScanNums[-1]]=float(format(self.specFitPar[0],'.3f'))
            except:
                self.peakPos='%.4f'%x[np.argmax(y)]
                self.peakCenter=self.peakPos
                self.peakFWHM='0'
        self.specPlotSettings()
        self.ui.statusBar.showMessage('Done')
         
    def specPlotSettings(self):
        self.spLogX=self.ui.spLogXCheckBox.checkState()
        self.spLogY=self.ui.spLogYCheckBox.checkState()
        self.spGrid=self.ui.spGridCheckBox.checkState()
        self.ui.specPlotMplWidget.canvas.ax.set_xscale('linear')
        self.ui.specPlotMplWidget.canvas.ax.set_yscale('linear')
        self.ui.specPlotMplWidget.canvas.ax.set_xlabel(str(self.ui.spXComboBox.currentText()))
        self.ui.specPlotMplWidget.canvas.ax.set_ylabel(str(self.ui.spYComboBox.currentText()))
        self.ui.specPlotMplWidget.canvas.ax.grid(b=False)
        if self.spLogX!=0:
            self.ui.specPlotMplWidget.canvas.ax.set_xscale('log')
        if self.spLogY!=0:
            self.ui.specPlotMplWidget.canvas.ax.set_yscale('log')
        if self.spGrid!=0:
            self.ui.specPlotMplWidget.canvas.ax.grid(b=True,color='r',linestyle='--')
        if self.ui.spLegendCheckBox.checkState()!=0:
            self.ui.specPlotMplWidget.canvas.ax.legend(loc=self.ui.spLegendLocComboBox.currentIndex()+1,frameon=False,scatterpoints=0,numpoints=1)
        self.ui.specPlotMplWidget.canvas.draw()
            
        
    def specPlot(self,x,y,n):
        yerr=pl.sqrt(y)
        if self.ui.spNCheckBox.checkState()!=0:
            yerr=pl.sqrt(y/n**2+y**2/n**3)
            y=y/n
        self.ui.specPlotMplWidget.canvas.ax.errorbar(x,y,yerr,label=self.label,fmt='o-')
        for i in range(len(x)):
            self.ui.specPlotMplWidget.canvas.ax.text(x[i],y[i],str(i),color='r',fontsize=16)
        
    def specPeakFit(self,x,y,yerr):
        par=[x[np.argmax(y)],np.abs(x[-1]-x[0])/2.0,np.max(y),0.0,0.0,np.abs(x[0]-x[1]),0.0,1]
        p=leastsq(self.specPeakRes1,par,args=(x,y,yerr),maxfev=5000)
        if p[0][1]<np.abs(x[0]-x[1]):
            p=leastsq(self.specPeakRes2,par,args=(x,y,yerr),maxfev=5000)
        self.specFitPar=p[0]
        
    
    def specPeakRes1(self,par,x,y,yerr):
        if np.all(np.where(yerr>0,1,0))==True:
            return (y-self.specPeakFun1(par,x))/yerr
        else:
            return (y-self.specPeakFun1(par,x))
            
    def specPeakRes2(self,par,x,y,yerr):
        if np.all(np.where(yerr>0,1,0))==True:
            return (y-self.specPeakFun2(par,x))/yerr
        else:
            return (y-self.specPeakFun2(par,x))
            
        
    def specPeakFun1(self, par, x):
        par[1]=np.abs(par[1])
        par[5]=np.abs(par[5])
        par[7]=-1
        return par[2]*((1+np.tanh((x-par[0]+par[1]/2)/par[5]))/2+(np.tanh(-(x-par[0]-par[1]/2)/par[5])+1)/2)+par[3]+par[4]*(x-par[0])+par[6]*(x-par[0])**2
    
    def specPeakFun2(self, par, x):
        par[1]=np.abs(par[1])
        sig=par[1]/2.0/np.sqrt(2.0*np.log(2.0))
        par[7]=1
        return par[2]*np.exp(-(x-par[0])**2/2.0/sig**2)+par[3]+par[4]*x
        

        
    def checkSameScans(self):
        scanvar=[self.specData[i]['ScanVar'] for i in self.selectedScanNums]
        return all(x==scanvar[0] for  x in scanvar)
    
    def checkSameQzs(self,qzvalues):
        return all(np.abs(x-qzvalues[0])<0.0001 for x in qzvalues)
        
    def checkSameArrays(self,anyarray):
        return all(x==anyarray[0] for x in anyarray)
        
    def updateMcaImageList(self):
        #self.disconnect(self.ui.imageListWidget,SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged)
        self.ui.statusBar.clearMessage()
        for i in self.selectedScanNums:
            self.ui.scanListWidget.setItemSelected(self.ui.scanListWidget.item(i),True)
        self.mcaFileNames=[self.mcafhead+str(i+1)+self.mcaftail for i in self.selectedScanNums]
        self.mcaData={}
        self.mcaPar={}
        start=0 
        for i in range(len(self.mcaFileNames)):  
            self.mcaread=mcaread(self.mcaFileNames[i],beamline=self.beamline)
            data=self.mcaread.Data
            par=self.mcaread.Par
            for j in range(data['NumOfScans']):                
                self.mcaData[start]=data[j]
                self.mcaPar[start]=par[j]
                self.ui.imageListWidget.addItem('S# '+str(self.selectedScanNums[i]+1)+'\tmS# '+str(j+1)+'\tQz='+str(self.mcaPar[start]['Q'][2]))
                start=start+1           
# self.connect(self.ui.imageListWidget,SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged)
        
    def mcaSelectedScanChanged(self):
        self.ui.statusBar.clearMessage()
        self.selectedMcaScans=self.ui.imageListWidget.selectedItems()
        self.selectedMcaScanNums=[self.ui.imageListWidget.row(items) for items in self.selectedMcaScans]
        try:
            self.ui.PlotWidget.setCurrentIndex(4)
            self.updateMcaPlotData()
        except:
            self.ui.statusBar.showMessage('Warning:: Some scans maybe missing')
            
            
            
    def updateMcaPlotData(self):
        self.ui.statusBar.clearMessage()
        self.ui.mcaPlotMplWidget.canvas.ax.clear()
        self.nomMcaData={}
        fact=1.0
        for i in self.selectedMcaScanNums:
            y=pl.array(self.mcaData[i]['Vortex'],dtype='float')
            x=pl.arange(1,len(y)+1)
            if self.ui.mcaCalibCheckBox.checkState()!=0:
                self.ui.mcaCalibConLineEdit.setText(str(self.mcaPar[i]['Calib'][0]))
                self.ui.mcaCalibLinLineEdit.setText(str(self.mcaPar[i]['Calib'][1]))
                self.ui.mcaCalibQuaLineEdit.setText(str(self.mcaPar[i]['Calib'][2]))
            con=float(self.ui.mcaCalibConLineEdit.text())
            lin=float(self.ui.mcaCalibLinLineEdit.text())
            qua=float(self.ui.mcaCalibQuaLineEdit.text())
            x=con+lin*x+qua*x**2
            n=self.mcaData[i]['Monc']*pl.ones_like(y)
            self.nomMcaData[i]=np.vstack((x,y/n,pl.sqrt(y+y**2/n)/n)).transpose()
            self.mcaLabel=str(i+1)+' Qz='+'%.4f'%self.mcaPar[i]['Q'][2]
            if self.ui.mcaOffsetCheckBox.checkState()!=0:
                fact=fact*float(self.ui.mcaOffsetLineEdit.text())
            self.mcaPlot(x,y,n,fact)
        self.mcaPlotSettings()
        self.ui.statusBar.showMessage('Done')
        
    def mcaPlot(self,x,y,n,fact):
        yerr=pl.sqrt(y)
        if self.ui.mcaNormCheckBox.checkState()!=0:
            yerr=pl.sqrt(y+y**2/n)/n
            y=y/n
        self.ui.mcaPlotMplWidget.canvas.ax.errorbar(x,fact*y,fact*yerr,label=self.mcaLabel,fmt='o-')

        
    def mcaPlotSettings(self):
        self.mcaLogX=self.ui.mcaLogXCheckBox.checkState()
        self.mcaLogY=self.ui.mcaLogYCheckBox.checkState()
        self.mcaGrid=self.ui.mcaGridCheckBox.checkState()
        self.ui.mcaPlotMplWidget.canvas.ax.set_xscale('linear')
        self.ui.mcaPlotMplWidget.canvas.ax.set_yscale('linear')
        self.ui.mcaPlotMplWidget.canvas.ax.set_xlabel('Energy')
        self.ui.mcaPlotMplWidget.canvas.ax.set_ylabel('Intensity')
        #self.ui.specPlotMplWidget.canvas.ax.legend('_nolegend_')
        self.ui.mcaPlotMplWidget.canvas.ax.grid(b=False)
        if self.mcaLogX!=0:
            self.ui.mcaPlotMplWidget.canvas.ax.set_xscale('log')
        if self.mcaLogY!=0:
            self.ui.mcaPlotMplWidget.canvas.ax.set_yscale('log')
        if self.mcaGrid!=0:
            self.ui.mcaPlotMplWidget.canvas.ax.grid(b=True,color='r',linestyle='--')
        if self.ui.mcaLegendCheckBox.checkState()!=0:
            self.ui.mcaPlotMplWidget.canvas.ax.legend(loc=self.ui.mcaLegendLocComboBox.currentIndex()+1,frameon=False,scatterpoints=0,numpoints=1)
        self.ui.mcaPlotMplWidget.canvas.draw()
            
    def saveMcaData(self):
        self.saveMcaFileName=str(QFileDialog.getSaveFileName(caption='Save Mca data'))
        for i in self.selectedMcaScanNums:
            self.fmcaName=self.saveMcaFileName+str(self.ui.imageListWidget.item(i).text().split('\t')[0])+'_'+'%.4f'%self.mcaPar[i]['Q'][2]+'.mca'
            np.savetxt(self.fmcaName,self.nomMcaData[i],fmt='%.4f\t%.4e\t%.4e')
            
    def messageBox(self,text,title='Warning'):
        mesgbox=QMessageBox()
        mesgbox.setText(text)
        mesgbox.setWindowTitle(title)
        mesgbox.exec_()
    
    def updateProgress(self):
        self.progressDialog.setValue(self.progressDialog.value()+1)
        
    def selectAllImages(self):
        if self.ui.imageSelectAllCheckBox.checkState()!=0:
            self.disconnect(self.ui.imageListWidget,SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged)
            for i in range(self.ui.imageListWidget.count()):
                self.ui.imageListWidget.setItemSelected(self.ui.imageListWidget.item(i),True)
            self.connect(self.ui.imageListWidget,SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged)
            self.imageSelectedScanChanged()
        else:
            self.unSelectedAllImages()
                
    def unSelectedAllImages(self):
        if self.ui.imageSelectAllCheckBox.checkState()!=0 and self.specPar[self.selectedScanNums[0]]['Detector']=='Bruker':
            self.disconnect(self.ui.imageListWidget,SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged)
            for items in self.selectedCcdFrames:
                self.ui.imageListWidget.setItemSelected(items,False)
            self.connect(self.ui.imageListWidget,SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged)
            self.ui.imageSelectAllCheckBox.setCheckState(0)
        elif self.ui.imageSelectAllCheckBox.checkState()!=0 and self.specPar[self.selectedScanNums[0]]['Detector']=='Pilatus':
            self.disconnect(self.ui.imageListWidget,SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged)
            for items in self.selectedPilFrames:
                self.ui.imageListWidget.setItemSelected(items,False)
            self.connect(self.ui.imageListWidget,SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged)
        elif self.ui.imageSelectAllCheckBox.checkState()!=0 and self.specPar[self.selectedScanNums[0]]['Detector']=='Vortex':
            self.ui.imageSelectAllCheckBox.setCheckState(0)
        self.ui.gixSumCheckBox.setCheckState(0)


    def imageSelectedScanChanged(self):
        #self.ui.imageSelectAllCheckBox.setCheckState(0)
        self.pilGIDshow=0
        self.ui.statusBar.showMessage('Plotting....Wait!!')
        if  self.specPar[self.selectedScanNums[0]]['Detector']=='Vortex':
            self.mcaSelectedScanChanged()
            self.ui.statusBar.showMessage('Done')
        elif self.specPar[self.selectedScanNums[0]]['Detector']=='Bruker':
            self.det='Bruker'            
            self.ccdSelectedScanChanged()
            self.ui.statusBar.showMessage('Done')
        elif self.specPar[self.selectedScanNums[0]]['Detector']=='Pilatus':
            self.det='Pilatus'
            self.pilSelectedScanChanged()
            self.ui.statusBar.showMessage('Done')
 
        
    def updateCcdImageList(self):
        self.disconnect(self.ui.imageListWidget,SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged)
        self.ui.statusBar.clearMessage()
        self.numFrames={}
        self.ccdFileNames=[]
        self.ccdFileQzs=[]
        self.ccdMonc=np.array([])
        self.ccdX=[]
        self.ccdY=[]
        self.ccd_Dist=[]
        self.ccdAlpha=[]
        self.ccd_Sh=[]
        self.ccd_Wavelength=[]
        self.ccd_Tth=[]
        self.ccd_Chi=[]
        self.ccd_Gl2=[]
        self.ccd_AbsNum=[]
        self.ccd_Phi=[]
        self.ccdX_off=[]
        self.ccdY_off=[]
        for i in self.selectedScanNums:
            #self.ui.scanListWidget.setItemSelected(self.ui.scanListWidget.item(i),True)
            try:
                self.numFrames[i]=len(self.specData[i][self.specData[i]['ScanVar'][0]])
                self.ccdMonc=np.append(self.ccdMonc, self.specData[i]['Monc'])
                for j in range(self.numFrames[i]):
                    self.ccdFileNames=self.ccdFileNames+[self.ccdfhead+str(i)+'_%04d'%(j,)+self.ccdftail]
                    self.ui.imageListWidget.addItem('S# '+str(i)+'\tF# '+str(j)+'\tQz='+'%.4f'%self.specData[i]['L'][j]+'\tQx='+'%.4f'%self.specData[i]['H'][j]+'\tAbs=%d'%self.specPar[i]['Absorber'])
                    self.ccdFileQzs.append(self.specData[i]['L'][j])
                    self.ccdAlpha.append(np.arcsin(self.ccdFileQzs[-1]*self.specPar[i]['Wavelength']/4.0/np.pi))
                    self.ccdX.append(self.specPar[i]['DBPos'][0])
                    self.ccd_Wavelength.append(self.specPar[i]['Wavelength'])
                    self.ccdY.append(self.specPar[i]['DBPos'][1])
                    self.ccdX_off.append(self.specPar[i]['CCD_X'])
                    self.ccdY_off.append(self.specPar[i]['CCD_Y'])
                    self.ccd_Dist.append(self.specPar[i]['S2D_Dist'])
                    self.ccd_Sh.append(self.specPar[i]['an_Sam_H'])
                    self.ccd_Tth.append(self.specPar[i]['Two_Thet'])
                    self.ccd_Chi.append(self.specPar[i]['Chi'])
                    self.ccd_Gl2.append(self.specPar[i]['g_l2'])
                    self.ccd_AbsNum.append(self.specPar[i]['Absorber'])
                    self.ccd_Phi.append(self.specPar[i]['Phi'])
            except:
                self.messageBox('Warning:: #S '+str(i+1)+' has been canceled or no data found.')
        self.ccdData={}
        self.ccdLogData={}
        self.ccdErrorData={}
        self.connect(self.ui.imageListWidget,SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged)

    def updatePilImageList(self):
        self.disconnect(self.ui.imageListWidget,SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged)
        self.ui.statusBar.clearMessage()
        self.numFrames={}
        self.pilFileNames=[]
        self.pilFileQzs=[]
        self.pilMonc=np.array([])
        self.pilX=[]
        self.pilY=[]
        self.pil_Dist=[]
        self.pilAlpha=[]
        self.pil_Sh=[]
        self.pil_Wavelength=[]
        self.pil_Tth=[]
        self.pil_Chi=[]
        self.pil_Gl2=[]
        self.pil_AbsNum=[]
        self.pil_Phi=[]
        self.pil_Dth=[]
        self.pilX_off=[]
        self.pilY_off=[]
        self.pilFileQxs=[]
        for i in self.selectedScanNums:
            #self.ui.scanListWidget.setItemSelected(self.ui.scanListWidget.item(i),True)
            try:
                self.numFrames[i]=len(self.specData[i][self.specData[i]['ScanVar'][0]])
                try:
                    self.pilMonc=np.append(self.pilMonc, self.specData[i]['Monc'])
                except:
                    self.pilMonc=np.append(self.pilMonc, self.specData[i]['monc'])   
                for j in range(self.numFrames[i]):
                    self.pilFileNames=self.pilFileNames+[self.pilfhead+str(i)+('_%04d')%(j,)+self.pilftail]
                    self.ui.imageListWidget.addItem('S# '+str(i)+'\tF# '+str(j)+'\tQz='+'%.4f'%self.specData[i]['L'][j]+'\tQx='+'%.4f'%self.specData[i]['H'][j]+'\tAbs=%d'%self.specPar[i]['Absorber'])
                    self.pilFileQzs.append(self.specData[i]['L'][j])
                    self.pilFileQxs.append(self.specData[i]['H'][j])
                    self.pilAlpha.append(np.arcsin(self.pilFileQzs[-1]*self.specPar[i]['Wavelength']/4.0/np.pi))
                    self.pilX.append(self.specPar[i]['DBPos'][1])
                    self.pil_Wavelength.append(self.specPar[i]['Wavelength'])
                    self.pilY.append(self.specPar[i]['DBPos'][0])
                    self.pil_Dist.append(self.specPar[i]['S2D_Dist'])
                    self.pil_Sh.append(self.specPar[i]['Sample_H'])
                    self.pil_Dth.append(2.0*np.arcsin(self.pilFileQxs[-1]*self.specPar[i]['Wavelength']/4.0/np.pi))
                    #self.pil_Dth.append(self.specPar[i]['Det_Th'])
                    self.pil_Tth.append(self.specPar[i]['Two_Thet'])
                    self.pil_Chi.append(self.specPar[i]['Chi'])
                    self.pil_Gl2.append(self.specPar[i]['g_l2'])
                    self.pil_AbsNum.append(self.specPar[i]['Absorber'])
                    self.pil_Phi.append(self.specPar[i]['Phi'])
            except:
                self.messageBox('Warning:: #S '+str(i+1)+' has been canceled or no data found.')
        self.pilData={}
        self.pilLogData={}
        self.pilErrorData={}
        self.connect(self.ui.imageListWidget,SIGNAL('itemSelectionChanged()'),self.imageSelectedScanChanged)

    def ccdSelectedScanChanged(self):
        self.ui.statusBar.clearMessage()
        self.selectedCcdFrames=self.ui.imageListWidget.selectedItems()
        bad_pix=int(self.ui.gixBPCfacLineEdit.text())
        self.selectedCcdFramesNums=[self.ui.imageListWidget.row(items) for items in self.selectedCcdFrames]
        self.ccdSelectedQzs=[self.ccdFileQzs[i] for i in self.selectedCcdFramesNums]
        self.ccdSelectedMonc=[self.ccdMonc[i] for i in self.selectedCcdFramesNums]
        self.ccdSelectedX=[self.ccdX[i] for i in self.selectedCcdFramesNums]   #this is the direct beam x pixel
        self.ccdSelectedY=[self.ccdY[i] for i in self.selectedCcdFramesNums]   # this is the direct beam y pixel
        self.ccdSelected_Dist=[self.ccd_Dist[i] for i in self.selectedCcdFramesNums]   # this is the distance btw sample and CCD
        self.ccdSelected_Sh=[-self.ccd_Gl2[i]*np.tan(self.ccdAlpha[i]) for i in self.selectedCcdFramesNums]#[self.ccd_Sh[i] for i in self.selectedCcdFramesNums]
        self.ccdSelectedXoff=[self.ccdX_off[i] for i in self.selectedCcdFramesNums]
        self.ccdSelectedYoff=[self.ccdY_off[i] for i in self.selectedCcdFramesNums]
        self.ccdSelected_Alpha=[self.ccdAlpha[i] for i in self.selectedCcdFramesNums]
        self.ccdSelected_Wavelength=[self.ccd_Wavelength[i] for i in self.selectedCcdFramesNums]
        self.ccdSelected_Tth=[self.ccd_Tth[i] for i in self.selectedCcdFramesNums]
        self.ccdSelected_Chi=[self.ccd_Chi[i] for i in self.selectedCcdFramesNums]
        self.ccdSelected_Gl2=[self.ccd_Gl2[i] for i in self.selectedCcdFramesNums]
        self.ccdSelected_AbsNum=[self.ccd_AbsNum[i] for i in self.selectedCcdFramesNums]
        self.ccdSelected_Phi=[self.ccd_Phi[i] for i in self.selectedCcdFramesNums]
        fac=float(self.ui.bgFacLineEdit.text())
        j=0
        self.progressDialog=QProgressDialog('Reading CCD Images','Abort',0,100)
        self.progressDialog.setWindowModality(Qt.WindowModal)
        self.progressDialog.setWindowTitle('Wait')
        self.progressDialog.setAutoClose(True)
        self.progressDialog.setAutoReset(True)
        self.progressDialog.setMinimum(1)
        self.progressDialog.setMaximum(len(self.selectedCcdFramesNums))
        self.progressDialog.show()
        self.ccdFrameNumsWithSameQz={}
        self.ccdFrameAbsWithSameQz={}
        for i in self.selectedCcdFramesNums:
            if float(format(self.ccdFileQzs[i],'.4f')) in self.ccdFrameNumsWithSameQz:                
                self.ccdFrameNumsWithSameQz[float(format(self.ccdFileQzs[i],'.4f'))].append(i)
                self.ccdFrameAbsWithSameQz[float(format(self.ccdFileQzs[i],'.4f'))].append(self.ccd_AbsNum[i])
            else:
                self.ccdFrameNumsWithSameQz[float(format(self.ccdFileQzs[i],'.4f'))]=[i]
                self.ccdFrameAbsWithSameQz[float(format(self.ccdFileQzs[i],'.4f'))]=[self.ccd_AbsNum[i]]
            if len(self.ui.backgroundListWidget.selectedItems())==0:
                self.bruker.openFile(self.ccdFileNames[i],bad_pix=bad_pix)
                self.ccdData[i]=self.bruker.imageData
                self.ccdLogData[i]=np.log10(self.ccdData[i]+1)
                self.ccdErrorData[i]=self.bruker.errorData
                self.xyzformat='x=%.3f,y=%.3f,z=%d'
            else:
                self.bruker.openFile(self.ccdFileNames[i],bad_pix=bad_pix)
                self.ccdData[i]=self.bruker.imageData
                self.ccdErrorData[i]=self.bruker.errorData
                self.bruker.sumFiles({i:self.ccdData[i]},{i:self.ccdErrorData[i]},absfac=self.absfac,absnum=[self.ccdSelected_AbsNum[j]],mon=[self.ccdSelectedMonc[j]]) # For the Normalization Calculation Only!!
                self.ccdData[i]=self.bruker.imageData-fac*self.bgData
                if self.ui.bgIgnoreNegCheckBox.checkState()!=0:
                    self.ccdData[i]=np.where(self.ccdData[i]<0,0,self.ccdData[i])
                self.ccdLogData[i]=np.log10(np.where(self.ccdData[i]<=0,1e-10,self.ccdData[i]))
                self.ccdErrorData[i]=np.sqrt(self.bruker.errorData**2+fac**2*self.bgError**2)
                j=j+1
                self.xyzformat='x=%.3f,y=%.3f,z=%.2e'
            self.progressDialog.setLabelText('Reading CCD Frame #'+str(i))     
            self.updateProgress()
            if self.progressDialog.wasCanceled()==True:
                break
        self.progressDialog.hide()
        try:
            self.imageMax=np.max(self.ccdData[self.selectedCcdFramesNums[0]])
            self.imageMin=np.max([1e-10,np.min(self.ccdData[self.selectedCcdFramesNums[0]])])
        except:
            self.imageMax=100
            self.imageMin=0
        self.ui.gixMaxLineEdit.setText(str(self.imageMax))
        self.ui.gixMinLineEdit.setText(str(self.imageMin))
        self.ui.gixMinHorizontalSlider.setRange(0, 100)
        self.ui.gixMaxHorizontalSlider.setRange(0, 100)
        self.ui.gixMinHorizontalSlider.setValue(0)
        self.ui.gixMaxHorizontalSlider.setValue(100)
#        try:
        self.ui.PlotWidget.setCurrentIndex(1)
        self.updateCcdPlotData()
#        except:
#            self.messageBox('Warning:: Some scans maybe missing')
            
    def pilSelectedScanChanged(self):
        self.ui.pilCutDirComboBox.clear()
        self.ui.pilCutDirComboBox.addItems(self.cutDirItems)
        bad_pix=int(self.ui.pilBPCfacLineEdit.text())
        self.ui.statusBar.clearMessage()
        self.selectedPilFrames=self.ui.imageListWidget.selectedItems()
        self.selectedPilFramesNums=[self.ui.imageListWidget.row(items) for items in self.selectedPilFrames]
        self.pilSelectedQzs=[self.pilFileQzs[i] for i in self.selectedPilFramesNums]
        self.pilSelectedMonc=[self.pilMonc[i] for i in self.selectedPilFramesNums]
        self.pilSelectedX=[self.pilX[i] for i in self.selectedPilFramesNums]   #this is the direct beam x pixel
        self.pilSelectedY=[self.pilY[i] for i in self.selectedPilFramesNums]   # this is the direct beam y pixel
        self.pilSelected_Dist=[self.pil_Dist[i] for i in self.selectedPilFramesNums]   # this is the distance btw sample and CCD
        self.pilSelected_Sh=[-self.pil_Gl2[i]*np.tan(self.pilAlpha[i]) for i in self.selectedPilFramesNums]#[self.ccd_Sh[i] for i in self.selectedCcdFramesNums]
#        self.ccdSelectedXoff=[self.ccdX_off[i] for i in self.selectedCcdFramesNums]
#        self.ccdSelectedYoff=[self.ccdY_off[i] for i in self.selectedCcdFramesNums]
        self.pilSelected_Alpha=[self.pilAlpha[i] for i in self.selectedPilFramesNums]
        self.pilSelected_Wavelength=[self.pil_Wavelength[i] for i in self.selectedPilFramesNums]
        self.pilSelected_Dth=[self.pil_Dth[i] for i in self.selectedPilFramesNums]
        self.pilSelected_Tth=[self.pil_Tth[i] for i in self.selectedPilFramesNums]
        self.pilSelected_Chi=[self.pil_Chi[i] for i in self.selectedPilFramesNums]
        self.pilSelected_Gl2=[self.pil_Gl2[i] for i in self.selectedPilFramesNums]
        self.pilSelected_AbsNum=[self.pil_AbsNum[i] for i in self.selectedPilFramesNums]
        self.pilSelected_Phi=[self.pil_Phi[i] for i in self.selectedPilFramesNums]
        fac=float(self.ui.bgFacLineEdit.text())
        j=0
        self.progressDialog=QProgressDialog('Reading Pilatus Images','Abort',0,100)
        self.progressDialog.setWindowModality(Qt.WindowModal)
        self.progressDialog.setWindowTitle('Wait')
        self.progressDialog.setAutoClose(True)
        self.progressDialog.setAutoReset(True)
        self.progressDialog.setMinimum(1)
        self.progressDialog.setMaximum(len(self.selectedPilFramesNums))
        self.progressDialog.show()
        self.pilFrameNumsWithSameQz={}
        self.pilFrameAbsWithSameQz={} 
        for i in self.selectedPilFramesNums:
            if float(format(self.pilFileQzs[i],'.4f')) in self.pilFrameNumsWithSameQz:                
                self.pilFrameNumsWithSameQz[float(format(self.pilFileQzs[i],'.4f'))].append(i)
                self.pilFrameAbsWithSameQz[float(format(self.pilFileQzs[i],'.4f'))].append(self.pil_AbsNum[i])
            else:
                self.pilFrameNumsWithSameQz[float(format(self.pilFileQzs[i],'.4f'))]=[i]
                self.pilFrameAbsWithSameQz[float(format(self.pilFileQzs[i],'.4f'))]=[self.pil_AbsNum[i]]
            if len(self.ui.backgroundListWidget.selectedItems())==0:
                self.pilatus.openFile(self.pilFileNames[i],bad_pix=bad_pix)
                self.pilData[i]=self.pilatus.imageData
                self.pilLogData[i]=np.log10(self.pilData[i]+1)
                self.pilErrorData[i]=self.pilatus.errorData
                self.xyzformat='x=%.3f,y=%.3f,z=%d'
            else:
                self.pilatus.openFile(self.pilFileNames[i],bad_pix=bad_pix)
                self.pilData[i]=self.pilatus.imageData
                self.pilErrorData[i]=self.pilatus.errorData
                self.pilatus.sumFiles({i:self.pilData[i]},{i:self.pilErrorData[i]},absfac=self.absfac,absnum=[self.pilSelected_AbsNum[j]],mon=[self.pilSelectedMonc[j]]) # For the Normalization Calculation Only!!
                self.pilData[i]=self.pilatus.imageData-fac*self.bgData
                if self.ui.bgIgnoreNegCheckBox.checkState()!=0:
                    self.pilData[i]=np.where(self.pilData[i]<0,0,self.pilData[i])
                self.pilLogData[i]=np.log10(np.where(self.pilData[i]<=0,1e-10,self.pilData[i]))
                self.pilErrorData[i]=np.sqrt(self.pilatus.errorData**2+fac**2*self.bgError**2)
                j=j+1
                self.xyzformat='x=%.3f,y=%.3f,z=%.2e'
            self.progressDialog.setLabelText('Reading Pilatus Frame #'+str(i))     
            self.updateProgress()
            if self.progressDialog.wasCanceled()==True:
                break
        self.progressDialog.hide()
        try:
            self.imageMax=np.max(self.pilData[self.selectedPilFramesNums[0]])
            if self.imageMax<1:
                self.imageMax=1
            self.imageMin=np.max([1e-10,np.min(self.pilData[self.selectedPilFramesNums[0]])])
        except:
            self.imageMax=100
            self.imageMin=0
        self.ui.pilMaxLineEdit.setText(str(self.imageMax))
        self.ui.pilMinLineEdit.setText(str(self.imageMin))
        self.ui.pilMinHorizontalSlider.setRange(0, 100)
        self.ui.pilMaxHorizontalSlider.setRange(0, 100)
        self.ui.pilMinHorizontalSlider.setValue(0)
        self.ui.pilMaxHorizontalSlider.setValue(100)
#        try:
        self.ui.PlotWidget.setCurrentIndex(2)
        self.updatePilPlotData()
#        except:
#            self.messageBox('Warning:: Some scans maybe missing')
            
    def updateMaxSlider(self):
        self.ui.gixMaxLineEdit.setText(str(self.ui.gixMaxHorizontalSlider.value()*(self.imageMax-self.imageMin)/100.0))
        self.ui.gixMinHorizontalSlider.setMaximum(int(float(self.ui.gixMaxLineEdit.text())*100.0/(self.imageMax-self.imageMin)))
        self.updateCcdPlotData()
        
    def updatePilMaxSlider(self):
        self.ui.pilMaxLineEdit.setText(str(self.ui.pilMaxHorizontalSlider.value()*(self.imageMax-self.imageMin)/100.0))
        self.ui.pilMinHorizontalSlider.setMaximum(int(float(self.ui.pilMaxLineEdit.text())*100.0/(self.imageMax-self.imageMin)))
        self.updatePilPlotData()
        
    def updateMinSlider(self):
        self.ui.gixMinLineEdit.setText(str(self.ui.gixMinHorizontalSlider.value()*(self.imageMax-self.imageMin)/100.0))
        self.updateCcdPlotData()
        
    def updatePilMinSlider(self):
        self.ui.pilMinLineEdit.setText(str(self.ui.pilMinHorizontalSlider.value()*(self.imageMax-self.imageMin)/100.0))
        self.updatePilPlotData()
        
    def addBGImagestoList(self):        
        self.ui.backgroundListWidget.clear()
        for item in self.ui.imageListWidget.selectedItems():
            self.ui.backgroundListWidget.addItem(item.text())
        self.bgccdData={}
        self.bgccdErrorData={}
        self.bgpilData={}
        self.bgpilErrorData={}
        self.bgMonc={}
        self.bgAbsNum={}
        j=0
        if self.det=='Bruker':
            for i in self.selectedCcdFramesNums:
                self.bgccdData[j]=self.ccdData[i]
                self.bgccdErrorData[j]=self.ccdErrorData[i]
                self.bgMonc[j]=self.ccdSelectedMonc[j]
                self.bgAbsNum[j]=self.ccdSelected_AbsNum[j]
                j=j+1
        elif self.det=='Pilatus':
            for i in self.selectedPilFramesNums:
                self.bgpilData[j]=self.pilData[i]
                self.bgpilErrorData[j]=self.pilErrorData[i]
                self.bgMonc[j]=self.pilSelectedMonc[j]
                self.bgAbsNum[j]=self.pilSelected_AbsNum[j]
                j=j+1
            
    def bgSelectAll(self):
        self.disconnect(self.ui.backgroundListWidget, SIGNAL('itemSelectionChanged()'),self.bgSelectionChanged)
        if self.ui.bgSelectAllCheckBox.checkState()!=0:
            for i in range(self.ui.backgroundListWidget.count()):
                self.ui.backgroundListWidget.setItemSelected(self.ui.backgroundListWidget.item(i),True)
        else:
            for i in range(self.ui.backgroundListWidget.count()):
                self.ui.backgroundListWidget.setItemSelected(self.ui.backgroundListWidget.item(i),False)
        self.connect(self.ui.backgroundListWidget, SIGNAL('itemSelectionChanged()'),self.bgSelectionChanged)
        self.bgSelectionChanged()
        
            
    def bgSelectionChanged(self):
        self.selectedBgFrameNums=[self.ui.backgroundListWidget.row(item) for item in self.ui.backgroundListWidget.selectedItems()]
        #print self.selectedBgFrameNums
        self.selectedBgData={}
        self.selectedBgError={}
        self.selectedBgAbsNum=[]
        self.selectedBgMonc=[]
        if self.det=='Bruker':
            for i in self.selectedBgFrameNums:
                self.selectedBgData[i]=self.bgccdData[i]
                self.selectedBgError[i]=self.bgccdErrorData[i]
                self.selectedBgMonc.append(self.bgMonc[i])
                self.selectedBgAbsNum.append(self.bgAbsNum[i])
                self.bruker.sumFiles(self.selectedBgData,self.selectedBgError,absfac=self.absfac,absnum=self.selectedBgAbsNum,mon=self.selectedBgMonc)
                self.bgData=self.bruker.imageData
                self.bgError=self.bruker.errorData
        elif self.det=='Pilatus':
            for i in self.selectedBgFrameNums:
                self.selectedBgData[i]=self.bgpilData[i]
                self.selectedBgError[i]=self.bgpilErrorData[i]
                self.selectedBgMonc.append(self.bgMonc[i])
                self.selectedBgAbsNum.append(self.bgAbsNum[i])
                self.pilatus.sumFiles(self.selectedBgData,self.selectedBgError,absfac=self.absfac,absnum=self.selectedBgAbsNum,mon=self.selectedBgMonc)
                self.bgData=self.pilatus.imageData
                self.bgError=self.pilatus.errorData
#        if len(self.ui.backgroundListWidget.selectedItems())>0:
#            self.ui.gixSumCheckBox.setCheckState(2)
        
        
    def removeBGImages(self):
        self.disconnect(self.ui.backgroundListWidget, SIGNAL('itemSelectionChanged()'),self.bgSelectionChanged)
        for item in self.ui.backgroundListWidget.selectedItems():
            self.ui.backgroundListWidget.takeItem(self.ui.backgroundListWidget.row(item))  
        self.connect(self.ui.backgroundListWidget, SIGNAL('itemSelectionChanged()'),self.bgSelectionChanged)
        self.ui.bgSelectAllCheckBox.setCheckState(0)
        
    def update2dPlots(self):
        if self.det=='Bruker':
            self.updateCcdPlotData()
        elif self.det=='Pilatus':
            self.updatePilPlotData()

            
    def updateCcdPlotData(self):
        if len(self.selectedCcdFramesNums)>10 and self.ui.gixSumCheckBox.checkState()<1:
            self.messageBox("The number of selected frames are more than 10. So plotting only first 10 images")
            N=10
        else:
            N=len(self.selectedCcdFramesNums)   
        self.ui.gixMplWidget.canvas.fig.clf()
        cmap=str(self.ui.gixCMapComboBox.currentText())
        self.ui.gixMaxHorizontalSlider.setValue(int(float(self.ui.gixMaxLineEdit.text())*100/(self.imageMax-self.imageMin)))
        self.ui.gixMinHorizontalSlider.setValue(int(float(self.ui.gixMinLineEdit.text())*100/(self.imageMax-self.imageMin)))
        vmax=float(self.ui.gixMaxLineEdit.text())
        vmin=float(self.ui.gixMinLineEdit.text())
        ccdXMin=np.ones_like(self.selectedCcdFramesNums)
        ccdYMin=np.ones_like(self.selectedCcdFramesNums)
        ccdXMax=float(self.bruker.NCOLS)*np.ones_like(self.selectedCcdFramesNums)
        ccdYMax=float(self.bruker.NROWS)*np.ones_like(self.selectedCcdFramesNums)
        xlabel='PixX'
        ylabel='PixY'
        self.wavelength=self.ccdSelected_Wavelength
        self.alpha=self.ccdSelected_Alpha
        if self.ui.gixSpecCheckBox.checkState()!=0:
            if self.checkSameArrays(self.ccdSelectedX)==False or self.checkSameArrays(self.ccdSelectedY)==False or self.checkSameArrays(self.ccdSelected_Dist)==False:
                self.messageBox('Warning:: The seleted frames have different CCD parameters; the parameters of the first frames are used here!!')
            self.ui.gixSDDistLineEdit.setText(str(self.ccdSelected_Dist[0]))
            self.ui.gixDBPosLineEdit.setText(str(self.ccdSelectedX[0])+','+str(self.ccdSelectedY[0]))
            self.ui.gixCcd_OffLineEdit.setText('%0.2f'%self.ccdSelectedXoff[0]+','+'%0.2f'%self.ccdSelectedYoff[0])
            self.xoff=np.array(map(int, np.array(self.ccdSelectedXoff)/0.06))
            self.yoff=np.array(map(int, np.array(self.ccdSelectedYoff)/0.06))
            self.distance=np.array(self.ccdSelected_Dist)
            self.xcenter=np.array(self.ccdSelectedX)
            self.ycenter=np.array(self.ccdSelectedY)
        else:
            self.xoff=np.array(map(int,float(self.ui.gixCcd_OffLineEdit.text().split(',')[0])*np.ones_like(self.selectedCcdFramesNums)/0.06))
            self.yoff=np.array(map(int,float(self.ui.gixCcd_OffLineEdit.text().split(',')[-1])*np.ones_like(self.selectedCcdFramesNums)/0.06))
            self.distance=float(self.ui.gixSDDistLineEdit.text())*np.ones_like(self.selectedCcdFramesNums)
            self.xcenter=float(self.ui.gixDBPosLineEdit.text().split(',')[0])*np.ones_like(self.selectedCcdFramesNums)
            self.ycenter=float(self.ui.gixDBPosLineEdit.text().split(',')[-1])*np.ones_like(self.selectedCcdFramesNums)
            
        if str(self.ui.gixAxesComboBox.currentText())=='Angles':
            xlabel='Psi [Degrees]'
            ylabel='Theta [Degrees]'
            ccdXMin=(ccdXMin-(self.xcenter-self.xoff))*0.06*180.0/np.pi/self.distance
            ccdXMax=(ccdXMax-(self.xcenter-self.xoff))*0.06*180.0/np.pi/self.distance
            ccdYMin=(((self.ycenter-self.yoff)-ccdYMin)*0.06-self.ccdSelected_Sh)*180.0/np.pi/self.distance
            ccdYMax=(((self.ycenter-self.yoff)-ccdYMax)*0.06-self.ccdSelected_Sh)*180.0/np.pi/self.distance
        elif str(self.ui.gixAxesComboBox.currentText())=='Q':
            xlabel='Qxy [1/Angs]'
            ylabel='Qz [1/Angs]'
            ccdXMin=4.0*np.pi*np.sin((ccdXMin-(self.xcenter-self.xoff))*0.06/self.distance/2.0)/self.wavelength
            ccdXMax=4.0*np.pi*np.sin((ccdXMax-(self.xcenter-self.xoff))*0.06/self.distance/2.0)/self.wavelength
            ccdYMin=2.0*np.pi*(np.sin((((self.ycenter-self.yoff)-ccdYMin)*0.06-self.ccdSelected_Sh)/self.distance)+np.sin(self.alpha))/self.wavelength
            ccdYMax=2.0*np.pi*(np.sin((((self.ycenter-self.yoff)-ccdYMax)*0.06-self.ccdSelected_Sh)/self.distance)+np.sin(self.alpha))/self.wavelength
            
        if self.ui.gixSumCheckBox.checkState()!=0:
            if self.checkSameQzs(self.ccdSelectedQzs)==True:
                self.sumData=self.ccdData[self.selectedCcdFramesNums[0]]
                for i in self.selectedCcdFramesNums[1:]:
                    self.sumData=self.sumData+self.ccdData[i]
                self.sumData=self.sumData/float(len(self.selectedCcdFramesNums))
                self.logData=np.log10(np.where(self.sumData<=0,1e-10,self.sumData))
                ax=self.ui.gixMplWidget.canvas.fig.add_subplot(1,1,1)
                ax.set_xlabel(xlabel)
                ax.set_ylabel(ylabel)
                ax.set_title('Sum'+str(self.selectedCcdFramesNums))
                self.extent=[ccdXMin[0],ccdXMax[0],ccdYMax[0],ccdYMin[0]]
                if self.ui.gixLogIntCheckBox.checkState()!=0:
                    p=ax.imshow(self.logData,interpolation='nearest',extent=self.extent,vmax=np.log10(vmax),vmin=np.log10(vmin),cmap=cmap,aspect='equal') 
                    self.Zdata=self.logData
                else:
                    p=ax.imshow(self.sumData,interpolation='nearest',extent=self.extent,vmax=vmax,vmin=vmin,cmap=cmap,aspect='equal')
                    self.Zdata=self.sumData 
                ax.format_coord=self.format_coord
                self.ui.gixMplWidget.canvas.fig.colorbar(p)
            else:
                self.messageBox('Error:: The selected frames have different qz values!!')
        else:
            row=2
            while N/row+pl.where(pl.mod(N,row)>0,1,0)>=row:
                row=row+1
            row=row-1
            col=N/row+pl.where(pl.mod(N,row)>0,1,0)
            num=1
            ax={}
            for i in self.selectedCcdFramesNums[:N]:
                ax[i]=self.ui.gixMplWidget.canvas.fig.add_subplot(row,col,num)
                ax[i].set_xlabel(xlabel)
                ax[i].set_ylabel(ylabel)
                ax[i].set_title('F #'+str(i))
                self.extent=[ccdXMin[num-1],ccdXMax[num-1],ccdYMax[num-1],ccdYMin[num-1]]
                if self.ui.gixLogIntCheckBox.checkState()!=0:
                    p=ax[i].imshow(self.ccdLogData[i],interpolation='nearest',extent=self.extent,vmax=np.log10(vmax),vmin=np.log10(vmin),cmap=cmap,aspect='equal')
                    self.Zdata=self.ccdLogData[i] 
                else:
                    p=ax[i].imshow(self.ccdData[i],interpolation='nearest',extent=self.extent,vmax=vmax,vmin=vmin,cmap=cmap,aspect='equal')
                    self.Zdata=self.ccdData[i]
                ax[i].format_coord=self.format_coord
                self.ui.gixMplWidget.canvas.fig.colorbar(p)
                num=num+1
        self.ui.gixMplWidget.canvas.draw()
        
        
    def updatePilPlotData(self):
        if self.pilGIDshow==0:
            if len(self.selectedPilFramesNums)>10 and self.ui.gixSumCheckBox.checkState()<1:
                self.messageBox("The number of selected frames are more than 10. So plotting only first 10 images")
                N=10
            else:
                N=len(self.selectedPilFramesNums)    
            self.ui.pilMplWidget.canvas.fig.clf()
            cmap=str(self.ui.pilCMapComboBox.currentText())
            self.ui.pilMaxHorizontalSlider.setValue(int(float(self.ui.pilMaxLineEdit.text())*100/(self.imageMax-self.imageMin)))
            self.ui.pilMinHorizontalSlider.setValue(int(float(self.ui.pilMinLineEdit.text())*100/(self.imageMax-self.imageMin)))
            vmax=float(self.ui.pilMaxLineEdit.text())
            vmin=float(self.ui.pilMinLineEdit.text())
            pilXMin=np.ones_like(self.selectedPilFramesNums)
            pilYMin=np.ones_like(self.selectedPilFramesNums)
            pilXMax=float(self.pilatus.NCOLS)*np.ones_like(self.selectedPilFramesNums)
            pilYMax=float(self.pilatus.NROWS)*np.ones_like(self.selectedPilFramesNums)
            xlabel='PixX'
            ylabel='PixY'
            self.wavelength=self.pilSelected_Wavelength
            self.alpha=self.pilSelected_Alpha
            self.dth=self.pilSelected_Dth
            if self.ui.pilSpecCheckBox.checkState()!=0:
                if self.checkSameArrays(self.pilSelectedX)==False or self.checkSameArrays(self.pilSelectedY)==False or self.checkSameArrays(self.pilSelected_Dist)==False:
                    self.messageBox('Warning:: The seleted frames have different Pilatus parameters; the parameters of the first frames are used here!!')
                try:
                    self.ui.pilSDDistLineEdit.setText(str(self.pilSelected_Dist[0]))
                    self.ui.pilDBPosLineEdit.setText(str(self.pilSelectedX[0])+','+str(self.pilSelectedY[0]))
                    self.distance=np.array(self.pilSelected_Dist)
                    self.xcenter=np.array(self.pilSelectedX)
                    self.ycenter=np.array(self.pilSelectedY)
                except:
                    pass
            else:
                self.distance=float(self.ui.pilSDDistLineEdit.text())*np.ones_like(self.selectedPilFramesNums)
                self.xcenter=float(self.ui.pilDBPosLineEdit.text().split(',')[0])*np.ones_like(self.selectedPilFramesNums)
                self.ycenter=float(self.ui.pilDBPosLineEdit.text().split(',')[-1])*npself.ui.pilSDDistLineEdit.setText(str(self.pilSelected_Dist[0]))
                self.ui.pilDBPosLineEdit.setText(str(self.pilSelectedX[0])+','+str(self.pilSelectedY[0]))
                self.distance=np.array(self.pilSelected_Dist)
                self.xcenter=np.array(self.pilSelectedX)
                self.ycenter=np.array(self.pilSelectedY).ones_like(self.selectedPilFramesNums)
            if str(self.ui.pilAxesComboBox.currentText())=='Angles':
                xlabel='Psi [Degrees]'
                ylabel='Theta [Degrees]'
                pilXMin=(self.dth+(pilXMin-self.xcenter)*0.172/self.distance)*180.0/np.pi
                pilXMax=(self.dth+(pilXMax-self.xcenter)*0.172/self.distance)*180.0/np.pi
                pilYMin=((pilYMin-self.ycenter)*0.172/self.distance+self.alpha)*180/np.pi
                pilYMax=((pilYMax-self.ycenter)*0.172/self.distance+self.alpha)*180/np.pi
            elif str(self.ui.pilAxesComboBox.currentText())=='Q':
                xlabel='Qxy [1/Angs]'
                ylabel='Qz [1/Angs]'
                pilXMin=4.0*np.pi*np.sin(self.dth+(pilXMin-self.xcenter)*0.172/self.distance/2.0)/self.wavelength
                pilXMax=4.0*np.pi*np.sin(self.dth+(pilXMax-self.xcenter)*0.172/self.distance/2.0)/self.wavelength
                pilYMin=2.0*np.pi*(np.sin((pilYMin-self.ycenter)*0.172/self.distance+self.alpha)+np.sin(self.alpha))/self.wavelength
                pilYMax=2.0*np.pi*(np.sin((pilYMax-self.ycenter)*0.172/self.distance+self.alpha)+np.sin(self.alpha))/self.wavelength
            if self.ui.gixSumCheckBox.checkState()!=0:
                if self.checkSameQzs(self.pilSelectedQzs)==True:
                    self.sumData=self.pilData[self.selectedPilFramesNums[0]]
                    for i in self.selectedPilFramesNums[1:]:
                        self.sumData=self.sumData+self.pilData[i]
                    self.sumData=self.sumData/float(len(self.selectedPilFramesNums))
                    self.logData=np.log10(np.where(self.sumData<=0,1e-10,self.sumData))
                    ax=self.ui.pilMplWidget.canvas.fig.add_subplot(1,1,1)
                    ax.set_xlabel(xlabel)
                    ax.set_ylabel(ylabel)
                    ax.set_title('Sum'+str(self.selectedPilFramesNums))
                    self.extent=[pilXMin[0],pilXMax[0],pilYMin[0],pilYMax[0]]
                    if self.ui.pilLogIntCheckBox.checkState()!=0:
                        p=ax.imshow(self.logData,interpolation='nearest',extent=self.extent,vmax=np.log10(vmax),vmin=np.log10(vmin),cmap=cmap,aspect='equal',origin='lower') 
                        self.Zdata=self.logData
                    else:
                        p=ax.imshow(self.sumData,interpolation='nearest',extent=self.extent,vmax=vmax,vmin=vmin,cmap=cmap,aspect='equal',origin='lower')
                        self.Zdata=self.sumData 
                    ax.format_coord=self.format_coord
                    self.ui.pilMplWidget.canvas.fig.colorbar(p)
                else:
                    self.messageBox('Error:: The selected frames have different qz values!!')
            else:
                row=2
                while N/row+pl.where(pl.mod(N,row)>0,1,0)>=row:
                    row=row+1
                row=row-1
                col=N/row+pl.where(pl.mod(N,row)>0,1,0)
                num=1
                ax={}
                for i in self.selectedPilFramesNums[:N]:
                    ax[i]=self.ui.pilMplWidget.canvas.fig.add_subplot(row,col,num)
                    ax[i].set_xlabel(xlabel)
                    ax[i].set_ylabel(ylabel)
                    ax[i].set_title('F #'+str(i))
                    self.extent=[pilXMin[num-1],pilXMax[num-1],pilYMin[num-1],pilYMax[num-1]]
                    if self.ui.pilLogIntCheckBox.checkState()!=0:
                        p=ax[i].imshow(self.pilLogData[i],interpolation='nearest',extent=self.extent,vmax=np.log10(vmax),vmin=np.log10(vmin),cmap=cmap,aspect='equal',origin='lower')
                        self.Zdata=self.pilLogData[i] 
                    else:
                        p=ax[i].imshow(self.pilData[i],interpolation='nearest',extent=self.extent,vmax=vmax,vmin=vmin,cmap=cmap,aspect='equal',origin='lower')
                        self.Zdata=self.pilData[i]
                    ax[i].format_coord=self.format_coord
                    self.ui.pilMplWidget.canvas.fig.colorbar(p)
                    num=num+1
            self.ui.pilMplWidget.canvas.draw()
        else:
            self.pilGIDPlot()

        
    def pilGIDPlot(self):
        self.pilGIDshow=1
        vmax=float(self.ui.pilMaxLineEdit.text())
        vmin=float(self.ui.pilMinLineEdit.text())
        self.ui.pilMplWidget.canvas.fig.clf()
        self.pilxleft=self.xcenter-float(self.ui.pilHSlitLineEdit.text())/2
        self.pilxright=self.xcenter+float(self.ui.pilHSlitLineEdit.text())/2
        self.pilhintData=[]
        cmap=str(self.ui.pilCMapComboBox.currentText())
        self.pilhintDataError=[]        
        self.absfac=float(self.ui.AbsFacLineEdit.text())
        pilXAxis=[]
        sortedFrameNums=np.array(self.selectedPilFramesNums)[np.argsort(np.array(self.pil_Dth))]
        for i in sortedFrameNums:
            self.pilatus.plotHint({i:self.pilData[i]},{i:self.pilErrorData[i]},absfac=self.absfac,absnum=[self.pil_AbsNum[i]],cen=[self.pilX[i],self.pilY[i]], hroi=[self.pilxleft[i]-1, self.pilxright[i]-1], wavelength=[self.pil_Wavelength[i]],s2d_dist=[self.pil_Dist[i]],sh=[self.pil_Sh[i]],alpha=[self.pilAlpha[i]], mon=[self.pilMonc[i]])
            self.pilhintData.append(self.pilatus.hintData[:,1])
            self.pilhintDataError.append(self.pilatus.hintData[:,2])
            pilXAxis.append(self.pil_Dth[i])
        pilYAxis=self.pilatus.hintData[:,0]
        pilXAxis=np.array(pilXAxis)
        self.pilhintData=np.array(self.pilhintData).transpose()
        self.pilhintErrorData=np.array(self.pilhintData).transpose()
        self.pilXAxs, self.pilYAxs=np.meshgrid(pilXAxis,pilYAxis)
        self.pil_xlabel='Psi [Degrees]'
        self.pil_ylabel='PixY'
        self.pilQz=2.0*np.pi*(np.sin((self.pilYAxs-self.ycenter[0])*0.172/self.distance[0]+self.alpha[0])+np.sin(self.alpha[0]))/self.wavelength[0]
        self.pilQxy=4.0*np.pi*np.sin(self.pilXAxs/2)/self.wavelength[0]
        if str(self.ui.pilAxesComboBox.currentText())=='Angles':
            self.pilYAxs=((self.pilYAxs-self.ycenter[0])*0.172/self.distance[0]+self.alpha[0])*180/np.pi
            self.pil_ylabel= 'Theta [Degrees]'
        elif str(self.ui.pilAxesComboBox.currentText())=='Q':
            self.pilYAxs=self.pilQz
            self.pilXAxs=self.pilQxy
            self.pil_xlabel='Qxy [1/Angs]'
            self.pil_ylabel='Qz [1/Angs]'
        self.gidax=self.ui.pilMplWidget.canvas.fig.add_subplot(1,1,1)
        if self.ui.pilLogIntCheckBox.checkState()!=0:
            self.gid_p=self.gidax.pcolor(self.pilXAxs, self.pilYAxs, np.log10(self.pilhintData),cmap=pl.cm.get_cmap(cmap),vmin=np.log10(vmin), vmax=np.log10(vmax))
        else:
            self.gid_p=self.gidax.pcolor(self.pilXAxs, self.pilYAxs, self.pilhintData,cmap=pl.cm.get_cmap(cmap),vmin=vmin, vmax=vmax)
        self.gidax.set_xlim((np.min(self.pilXAxs),np.max(self.pilXAxs)))
        self.gidax.set_ylim((np.min(self.pilYAxs),np.max(self.pilYAxs)))
        self.gidax.set_aspect('equal')
        self.gidax.set_xlabel(self.pil_xlabel)
        self.gidax.set_ylabel(self.pil_ylabel)
        self.ui.pilMplWidget.canvas.fig.colorbar(self.gid_p)
        self.ui.pilMplWidget.canvas.draw() 
        self.ui.pilCutDirComboBox.removeItem(0)
        self.ui.pilCutDirComboBox.removeItem(1)         

    def format_coord(self,x,y):
        numrows, numcols = self.Zdata.shape
        col = int(np.abs((x-self.extent[0]))*numrows/np.abs((self.extent[1]-self.extent[0])))
        row = int(np.abs((y-self.extent[3]))*numcols/np.abs((self.extent[3]-self.extent[2])))
        if col>=0 and col<numcols and row>=0 and row<numrows:
            z = self.Zdata[row,col]
            return self.xyzformat%(x, y, z)
        else:
            return 'x=%.2f, y=%.2f'%(x, y)
        
    def format_coord_ref(self,x,y):
        numrows, numcols = self.refZdata.shape
        col = int(np.abs((x-self.extent[0]))*numrows/np.abs((self.extent[1]-self.extent[0])))
        row = int(np.abs((y-self.extent[3]))*numcols/np.abs((self.extent[3]-self.extent[2])))
        if col>=0 and col<numcols and row>=0 and row<numrows:
            z = self.refZdata[row,col]
            return 'x=%d,y=%d,z=%.1e'%(x, y, z)
        else:
            return 'x=%d, y=%d'%(x, y)
        
    def refPlotWin(self):
#        if self.ui.gixSumCheckBox.checkState()==0:
#            self.ui.gixSumCheckBox.setCheckState(2)
#            self.messageBox('Warning:: Multiple frames selected, summing over all the frames for Reflectivity!!')
#            self.updateCcdPlotData()
        self.ui.PlotWidget.setCurrentIndex(3)
        self.ui.refCenCheckBox.setCheckState(0)
        self.ui.refComLineEdit.clear()
        if self.det=='Bruker':
            self.updateRefCcdPlotData()
        elif self.det=='Pilatus':
            self.updateRefPilPlotData()
        
       
    def updateRefCcdPlotData(self):
        self.ui.refADDataPlotWidget.canvas.fig.clf()
        dist=float(self.ui.gixSDDistLineEdit.text())
        cmap=str(self.ui.gixCMapComboBox.currentText())
        self.disconnect(self.ui.refQzListWidget, SIGNAL('itemSelectionChanged()'),self.refQzListSelectionChanged)
        self.ui.refQzListWidget.clear()
        self.scanframe={}
        self.refSortedFrameNums={}
        if self.ui.gixMergeSameQzCheckBox.checkState()!=0:
            j=0
            for key in sorted(self.ccdFrameNumsWithSameQz.keys()):
                self.scanframe[key]={}
                for item in self.ccdFrameNumsWithSameQz[key]:
                    ekey=int(str(self.ui.imageListWidget.item(item).text()).split('\t')[0].split('#')[1])
                    if ekey in self.scanframe[key]:
                        self.scanframe[key][ekey].append(int(str(self.ui.imageListWidget.item(item).text()).split('\t')[1].split('#')[1]))
                    else:
                        self.scanframe[key][ekey]=[int(str(self.ui.imageListWidget.item(item).text()).split('\t')[1].split('#')[1])]
                if all(x==self.ccdFrameAbsWithSameQz[key][0] for x in self.ccdFrameAbsWithSameQz[key]):                   
                    self.ui.refQzListWidget.addItem('Qz= '+str(key)+'\t {S:F}= '+str(self.scanframe[key])+'\t Abs= '+str([self.ccdFrameAbsWithSameQz[key][0]]))
                    self.refSortedFrameNums[j]=self.ccdFrameNumsWithSameQz[key]
                    j=j+1
                else:
                    for i in range(len(self.ccdFrameNumsWithSameQz[key])):
                        sftext=str(self.ui.imageListWidget.item(self.ccdFrameNumsWithSameQz[key][i]).text()).split('\t')
                        self.ui.refQzListWidget.addItem('Qz= '+str(key)+'\t {S:F}= '+str({int(sftext[0].split('#')[1]):[int(sftext[1].split('#')[1])]})+'\t Abs= '+str([self.ccdFrameAbsWithSameQz[key][i]]))
                        self.refSortedFrameNums[j]=[self.ccdFrameNumsWithSameQz[key][i]]
                        j=j+1
        else:
            j=0
            for i in self.selectedCcdFramesNums:
                sftext=str(self.ui.imageListWidget.item(i).text()).split('\t')
                self.ui.refQzListWidget.addItem('Qz= '+str(self.ccdFileQzs[i])+'\t {S:F}= '+str({int(sftext[0].split('#')[1]):[int(sftext[1].split('#')[1])]})+'\t Abs='+str(self.ccd_AbsNum[i]))
                self.refSortedFrameNums[j]=[i]
                j=j+1
        self.connect(self.ui.refQzListWidget, SIGNAL('itemSelectionChanged()'),self.refQzListSelectionChanged)
        self.ui.refQzListWidget.setItemSelected(self.ui.refQzListWidget.item(0),True)
        
    def updateRefPilPlotData(self):
        self.ui.refADDataPlotWidget.canvas.fig.clf()
        dist=float(self.ui.pilSDDistLineEdit.text())
        cmap=str(self.ui.pilCMapComboBox.currentText())
        self.disconnect(self.ui.refQzListWidget, SIGNAL('itemSelectionChanged()'),self.refQzListSelectionChanged)
        self.ui.refQzListWidget.clear()
        self.scanframe={}
        self.refSortedFrameNums={}
        if self.ui.pilMergeSameQzCheckBox.checkState()!=0:
            j=0
            for key in sorted(self.pilFrameNumsWithSameQz.keys()):
                self.scanframe[key]={}
                for item in self.pilFrameNumsWithSameQz[key]:
                    ekey=int(str(self.ui.imageListWidget.item(item).text()).split('\t')[0].split('#')[1])
                    if ekey in self.scanframe[key]:
                        self.scanframe[key][ekey].append(int(str(self.ui.imageListWidget.item(item).text()).split('\t')[1].split('#')[1]))
                    else:
                        self.scanframe[key][ekey]=[int(str(self.ui.imageListWidget.item(item).text()).split('\t')[1].split('#')[1])]
                if all(x==self.pilFrameAbsWithSameQz[key][0] for x in self.pilFrameAbsWithSameQz[key]):                   
                    self.ui.refQzListWidget.addItem('Qz= '+str(key)+'\t {S:F}= '+str(self.scanframe[key])+'\t Abs= '+str([self.pilFrameAbsWithSameQz[key][0]]))
                    self.refSortedFrameNums[j]=self.pilFrameNumsWithSameQz[key]
                    j=j+1
                else:
                    for i in range(len(self.pilFrameNumsWithSameQz[key])):
                        sftext=str(self.ui.imageListWidget.item(self.pilFrameNumsWithSameQz[key][i]).text()).split('\t')
                        self.ui.refQzListWidget.addItem('Qz= '+str(key)+'\t {S:F}= '+str({int(sftext[0].split('#')[1]):[int(sftext[1].split('#')[1])]})+'\t Abs= '+str([self.pilFrameAbsWithSameQz[key][i]]))
                        self.refSortedFrameNums[j]=[self.pilFrameNumsWithSameQz[key][i]]
                        j=j+1
        else:
            j=0
            for i in self.selectedPilFramesNums:
                sftext=str(self.ui.imageListWidget.item(i).text()).split('\t')
                self.ui.refQzListWidget.addItem('Qz= '+str(self.pilFileQzs[i])+'\t {S:F}= '+str({int(sftext[0].split('#')[1]):[int(sftext[1].split('#')[1])]})+'\t Abs='+str(self.pil_AbsNum[i]))
                self.refSortedFrameNums[j]=[i]
                j=j+1
        self.connect(self.ui.refQzListWidget, SIGNAL('itemSelectionChanged()'),self.refQzListSelectionChanged)
        self.ui.refQzListWidget.setItemSelected(self.ui.refQzListWidget.item(0),True)
        
    def refQzListSelectionChanged(self):
        self.ui.refADDataPlotWidget.canvas.fig.clf()
        cmap=str(self.ui.pilCMapComboBox.currentText())
        self.refQzSelectedItems=self.ui.refQzListWidget.selectedItems()        
        self.refQzSelected=float(str(self.refQzSelectedItems[0].text()).split()[1])
        self.absfac=float(self.ui.AbsFacLineEdit.text())
        slitx=int(self.ui.refSlitLineEdit.text().split(',')[0])
        slity=int(self.ui.refSlitLineEdit.text().split(',')[1])
        self.slit=[slitx,slity]
        self.bg=float(self.ui.refBGOffLineEdit.text())
        self.dir=str(self.ui.refBGDirComboBox.currentText())
        if self.det=='Bruker':
            dist=float(self.ui.gixSDDistLineEdit.text())
            self.selFrameNums=self.refSortedFrameNums[self.ui.refQzListWidget.row(self.refQzSelectedItems[0])]
            cenx=self.ccdX[self.selFrameNums[0]]-int((dist+self.ccd_Gl2[self.selFrameNums[0]])*(np.tan(self.ccd_Tth[self.selFrameNums[0]]*np.pi/180)-np.tan(2*self.ccd_Phi[self.selFrameNums[0]]*np.pi/180))/0.06)
            ceny=self.ccdY[self.selFrameNums[0]]-int((self.ccdAlpha[self.selFrameNums[0]]*dist+self.ccd_Sh[self.selFrameNums[0]])/0.06)
            self.mon=[self.ccdMonc[i] for i in self.selFrameNums]
            self.absnum=[self.ccd_AbsNum[i] for i in self.selFrameNums]
            self.vmax=float(self.ui.gixMaxLineEdit.text())
            self.vmin=float(self.ui.gixMinLineEdit.text())
            self.cen=[cenx,ceny]
            if self.ui.refCenCheckBox.checkState()==0:
                self.ui.refCenLineEdit.setText(str(self.cen[0])+','+str(self.cen[1]))
            else:
                self.cen=[int(self.ui.refCenLineEdit.text().split(',')[0]),int(self.ui.refCenLineEdit.text().split(',')[1])]  
            self.selData={}
            self.selErrorData={}
            if self.dir=='H':
                self.bg=self.bg*self.ccd_Dist[self.selFrameNums[0]]*np.pi/180/0.06/slitx
            else:
                self.bg=self.bg*self.ccd_Dist[self.selFrameNums[0]]*np.pi/180/0.06/slity         
            for i in self.selFrameNums:
                self.selData[i]=self.ccdData[i]
                self.selErrorData[i]=self.ccdErrorData[i]
            self.bruker.setROI(self.selData,self.selErrorData,absfac=self.absfac,absnum=self.absnum,slit=self.slit,cen=self.cen,bg=self.bg,dir=self.dir,mon=self.mon)
            slit=[self.slit[1], self.slit[0]]
            cen=[self.cen[1], self.cen[0]]
            self.ax={}
            if self.dir=='H':
                self.refextent=[self.bruker.bglcen-slit[1], self.bruker.bgrcen+slit[1]+1, cen[0]+slit[0]+1, cen[0]-slit[0]]
                self.ax[1]=self.ui.refADDataPlotWidget.canvas.fig.add_subplot(2,1,1)
                self.vmax=np.max(self.bruker.imageData[cen[0]-slit[0]:cen[0]+slit[0]+1, self.bruker.bglcen-slit[1]:self.bruker.bgrcen+slit[1]+1])
                self.vmin=np.max(self.bruker.imageData[cen[0]-slit[0]:cen[0]+slit[0]+1, self.bruker.bglcen-slit[1]:self.bruker.bgrcen+slit[1]+1])
                self.refZdata=self.bruker.imageData
                p=self.ax[1].imshow(self.bruker.imageROI[cen[0]-slit[0]:cen[0]+slit[0]+1, self.bruker.bglcen-slit[1]:self.bruker.bgrcen+slit[1]+1], origin='upper', aspect='auto', vmax=self.vmax, cmap=cmap, extent=self.refextent, interpolation='nearest')
                self.ax[1].set_ylabel('w/o Corr')
                self.ax[1].format_coord=self.format_coord_ref
            else:
                self.refextent=[cen[1]+slit[1]+1, cen[1]-slit[1], self.bruker.bgucen-slit[0], self.bruker.bgdcen+slit[0]+1]
                self.ax[1]=self.ui.refADDataPlotWidget.canvas.fig.add_subplot(1,2,1)            
                self.vmax=np.max(self.bruker.imageData[cen[0]-slit[0]:cen[0]+slit[0]+1, self.bruker.bglcen-slit[1]:self.bruker.bgrcen+slit[1]+1])
                self.vmin=np.max(self.bruker.imageData[cen[0]-slit[0]:cen[0]+slit[0]+1, self.bruker.bglcen-slit[1]:self.bruker.bgrcen+slit[1]+1])
                self.refZdata=self.bruker.imageData
                p=self.ax[1].imshow(self.bruker.imageROI[self.bruker.bgucen-slit[0]:self.bruker.bgdcen+slit[0]+1,cen[1]-slit[1]:cen[1]+slit[1]+1], origin='upper', aspect='auto', vmax=self.vmax, cmap=cmap, extent=self.refextent, interpolation='nearest')
                self.ax[1].set_ylabel('w/o Corr')
                self.ax[1].format_coord=self.format_coord_ref
            self.ui.refADDataPlotWidget.canvas.fig.colorbar(p)
            self.ui.refADDataPlotWidget.canvas.draw()
        elif self.det=='Pilatus':        
            self.selFrameNums=self.refSortedFrameNums[self.ui.refQzListWidget.row(self.refQzSelectedItems[0])]
            cenx=self.pilX[self.selFrameNums[0]]
            ceny=self.pilY[self.selFrameNums[0]]
            self.mon=[self.pilMonc[i] for i in self.selFrameNums]
            self.absnum=[self.pil_AbsNum[i] for i in self.selFrameNums]
            self.vmax=float(self.ui.pilMaxLineEdit.text())
            self.vmin=float(self.ui.pilMinLineEdit.text())
            self.cen=[cenx,ceny]
            if self.ui.refCenCheckBox.checkState()==0:
                self.ui.refCenLineEdit.setText(str(self.cen[0])+','+str(self.cen[1]))
            else:
                self.cen=[int(self.ui.refCenLineEdit.text().split(',')[0]),int(self.ui.refCenLineEdit.text().split(',')[1])]  
            self.selData={}
            self.selErrorData={}
            if self.dir=='H':
                self.bg=self.bg*self.pil_Dist[self.selFrameNums[0]]*np.pi/180/0.172/slitx
            else:
                self.bg=self.bg*self.pil_Dist[self.selFrameNums[0]]*np.pi/180/0.172/slity         
            for i in self.selFrameNums:
                self.selData[i]=self.pilData[i]
                self.selErrorData[i]=self.pilErrorData[i]
            self.pilatus.setROI(self.selData,self.selErrorData,absfac=self.absfac,absnum=self.absnum,slit=self.slit,cen=self.cen,bg=self.bg,dir=self.dir,mon=self.mon)
            slit=[self.slit[1], self.slit[0]]
            cen=[self.cen[1], self.cen[0]]
            self.ax={}
            if self.dir=='H':
                self.refextent=[self.pilatus.bglcen-slit[1], self.pilatus.bgrcen+slit[1]+1, cen[0]-slit[0], cen[0]+slit[0]+1]
                self.ax[1]=self.ui.refADDataPlotWidget.canvas.fig.add_subplot(2,1,1)
                self.vmax=np.max(self.pilatus.imageData[cen[0]-slit[0]:cen[0]+slit[0]+1, self.pilatus.bglcen-slit[1]:self.pilatus.bgrcen+slit[1]+1])
                self.vmin=np.max(self.pilatus.imageData[cen[0]-slit[0]:cen[0]+slit[0]+1, self.pilatus.bglcen-slit[1]:self.pilatus.bgrcen+slit[1]+1])
                self.refZdata=self.pilatus.imageData
                p=self.ax[1].imshow(self.pilatus.imageROI[cen[0]-slit[0]:cen[0]+slit[0]+1, self.pilatus.bglcen-slit[1]:self.pilatus.bgrcen+slit[1]+1], origin='lower', aspect='auto', vmax=self.vmax, cmap=cmap, extent=self.refextent, interpolation='nearest')
                self.ax[1].set_ylabel('w/o Corr')
                self.ax[1].format_coord=self.format_coord_ref
            else:
                self.refextent=[cen[1]+slit[1]+1, cen[1]-slit[1], self.pilatus.bgucen-slit[0], self.pilatus.bgdcen+slit[0]+1]
                self.ax[1]=self.ui.refADDataPlotWidget.canvas.fig.add_subplot(1,2,1)            
                self.vmax=np.max(self.pilatus.imageData[cen[0]-slit[0]:cen[0]+slit[0]+1, self.pilatus.bglcen-slit[1]:self.pilatus.bgrcen+slit[1]+1])
                self.vmin=np.max(self.pilatus.imageData[cen[0]-slit[0]:cen[0]+slit[0]+1, self.pilatus.bglcen-slit[1]:self.pilatus.bgrcen+slit[1]+1])
                self.refZdata=self.pilatus.imageData
                p=self.ax[1].imshow(self.pilatus.imageROI[self.pilatus.bgucen-slit[0]:self.pilatus.bgdcen+slit[0]+1,cen[1]-slit[1]:cen[1]+slit[1]+1], origin='lower', aspect='auto', vmax=self.vmax, cmap=cmap, extent=self.refextent, interpolation='nearest')
                self.ax[1].set_ylabel('w/o Corr')
                self.ax[1].format_coord=self.format_coord_ref
            self.ui.refADDataPlotWidget.canvas.fig.colorbar(p)
            self.ui.refADDataPlotWidget.canvas.draw()
        
        
        
    def refAnalyze(self):
        self.refQzListSelectionChanged()
        cmap=str(self.ui.gixCMapComboBox.currentText())
        if self.det=='Bruker':
            self.ui.refBadPixListWidget.clear()
            fac=float(self.ui.refSeaWinLineEdit.text())
            self.cenfit=0
            if self.ui.refCenCheckBox.checkState()!=0:
                self.cen=[int(self.ui.refCenLineEdit.text().split(',')[0]),int(self.ui.refCenLineEdit.text().split(',')[1])]
                self.cenfit=1
            self.par=self.bruker.peakFind(self.selData,self.selErrorData,slit=self.slit,cen=self.cen,absfac=self.absfac,absnum=self.absnum,fac=fac,mon=self.mon,cenfit=self.cenfit)
            self.cen=[int(np.floor(self.par[1])), int(np.floor(self.par[3]))]
            slit=[self.slit[1], self.slit[0]]
            cen=[self.cen[1], self.cen[0]]
            bfac=float(self.ui.refBPCFacLineEdit.text())
            try:
                sig,sigerr,lbg,lbgerr,rbg,rbgerr=self.bruker.badPix_corr(par=self.par,slit=self.slit,cen=self.cen,bad=1,bfac=bfac,dir=self.dir,bg=self.bg,plot=0)
            except:
                self.messageBox('Warning:: Please change to different search window by +/- 0.5.')
            if self.dir=='H':
                self.ui.refBadPixListWidget.addItem('------Signal------')
                for items in self.bruker.badSig:
                    self.ui.refBadPixListWidget.addItem(str(items[0])+'\t'+str(items[1]))
                self.ui.refBadPixListWidget.addItem('------Left BG------')
                for items in self.bruker.badLeft:
                    self.ui.refBadPixListWidget.addItem(str(items[0])+'\t'+str(items[1]))
                self.ui.refBadPixListWidget.addItem('------Right BG------')
                for items in self.bruker.badRight:
                    self.ui.refBadPixListWidget.addItem(str(items[0])+'\t'+str(items[1]))
            else:
                self.ui.refBadPixListWidget.addItem('------Signal------')
                for items in self.bruker.badSig:
                    self.ui.refBadPixListWidget.addItem(str(items[0])+'\t'+str(items[1]))
                self.ui.refBadPixListWidget.addItem('------Up BG------')
                for items in self.bruker.badUp:
                    self.ui.refBadPixListWidget.addItem(str(items[0])+'\t'+str(items[1]))
                self.ui.refBadPixListWidget.addItem('-----Down BG------')
                for items in self.bruker.badDown:
                    self.ui.refBadPixListWidget.addItem(str(items[0])+'\t'+str(items[1]))
            self.bruker.setROI(self.bruker.imageData,self.bruker.errorData,slit=self.slit,cen=self.cen,absfac=self.absfac,absnum=self.absnum,bg=self.bg,dir=self.dir,mon=None)  
            if self.dir=='H':            
                self.ax[2]=self.ui.refADDataPlotWidget.canvas.fig.add_subplot(2,1,2)
                self.refextent=[ self.bruker.bglcen-slit[1], self.bruker.bgrcen+slit[1]+1, cen[0]+slit[0]+1, cen[0]-slit[0]]
                self.vmax=np.max(self.bruker.imageData[cen[0]-slit[0]:cen[0]+slit[0]+1, self.bruker.bglcen-slit[1]:self.bruker.bgrcen+slit[1]+1])
                self.vmin=np.min(self.bruker.imageData[cen[0]-slit[0]:cen[0]+slit[0]+1, self.bruker.bglcen-slit[1]:self.bruker.bgrcen+slit[1]+1])
                p=self.ax[2].imshow(self.bruker.imageROI[cen[0]-slit[0]:cen[0]+slit[0]+1, self.bruker.bglcen-slit[1]:self.bruker.bgrcen+slit[1]+1], origin='upper', aspect='auto', vmax=self.vmax, cmap=cmap, extent=self.refextent, interpolation='nearest')
                self.ax[2].set_ylabel('w Corr')
                self.ax[2].format_coord=self.format_coord_ref
            else:
                self.ax[2]=self.ui.refADDataPlotWidget.canvas.fig.add_subplot(1,2,2)
                self.ax[2].clear()
                self.refextent=[cen[1]+slit[1]+1, cen[1]-slit[1], self.bruker.bgucen-slit[0], self.bruker.bgdcen+slit[0]+1]
                self.vmax=np.max(self.bruker.imageData[self.bruker.bgucen-slit[0]:self.bruker.bgdcen+slit[0]+1,cen[1]-slit[1]:cen[1]+slit[1]+1])
                self.vmin=np.min(self.bruker.imageData[self.bruker.bgucen-slit[0]:self.bruker.bgdcen+slit[0]+1,cen[1]-slit[1]:cen[1]+slit[1]+1])
                p=self.ax[2].imshow(self.bruker.imageROI[self.bruker.bgucen-slit[0]:self.bruker.bgdcen+slit[0]+1,cen[1]-slit[1]:cen[1]+slit[1]+1], origin='upper', aspect='auto', vmax=self.vmax, cmap=cmap, extent=self.refextent, interpolation='nearest')
                self.ax[2].set_ylabel('w Corr')
                self.ax[2].format_coord=self.format_coord_ref
        elif self.det=='Pilatus':
            self.ui.refBadPixListWidget.clear()
            fac=float(self.ui.refSeaWinLineEdit.text())
            self.cenfit=1
            #Peak searching is dummy it is not doing anything#
            if self.ui.refCenCheckBox.checkState()!=0:
                self.cen=[int(self.ui.refCenLineEdit.text().split(',')[0]),int(self.ui.refCenLineEdit.text().split(',')[1])]
            self.par=self.pilatus.peakFind(self.selData,self.selErrorData,slit=self.slit,cen=self.cen,absfac=self.absfac,absnum=self.absnum,fac=fac,mon=self.mon,cenfit=self.cenfit)
            self.cen=[int(np.floor(self.par[1])), int(np.floor(self.par[3]))]
            slit=[self.slit[1], self.slit[0]]
            cen=[self.cen[1], self.cen[0]]
            bfac=float(self.ui.refBPCFacLineEdit.text())
            sig,sigerr,lbg,lbgerr,rbg,rbgerr=self.pilatus.sumROI(slit=self.slit,cen=self.cen,dir=self.dir,bg=self.bg)
            self.pilatus.setROI(self.pilatus.imageData,self.pilatus.errorData,slit=self.slit,cen=self.cen,absfac=self.absfac,absnum=self.absnum,bg=self.bg,dir=self.dir,mon=None)  
            if self.dir=='H':
                self.refextent=[self.pilatus.bglcen-slit[1], self.pilatus.bgrcen+slit[1]+1, cen[0]-slit[0], cen[0]+slit[0]+1]
                self.ax[2]=self.ui.refADDataPlotWidget.canvas.fig.add_subplot(2,1,2)
                self.vmax=np.max(self.pilatus.imageData[cen[0]-slit[0]:cen[0]+slit[0]+1, self.pilatus.bglcen-slit[1]:self.pilatus.bgrcen+slit[1]+1])
                self.vmin=np.max(self.pilatus.imageData[cen[0]-slit[0]:cen[0]+slit[0]+1, self.pilatus.bglcen-slit[1]:self.pilatus.bgrcen+slit[1]+1])
                self.refZdata=self.pilatus.imageData
                p=self.ax[2].imshow(self.pilatus.imageROI[cen[0]-slit[0]:cen[0]+slit[0]+1, self.pilatus.bglcen-slit[1]:self.pilatus.bgrcen+slit[1]+1], origin='lower', aspect='auto', vmax=self.vmax, cmap=cmap, extent=self.refextent, interpolation='nearest')
                self.ax[2].set_ylabel('w Corr')
                self.ax[2].format_coord=self.format_coord_ref
            else:
                self.refextent=[cen[1]+slit[1]+1, cen[1]-slit[1], self.pilatus.bgucen-slit[0], self.pilatus.bgdcen+slit[0]+1]
                self.ax[2]=self.ui.refADDataPlotWidget.canvas.fig.add_subplot(1,2,2)            
                self.vmax=np.max(self.pilatus.imageData[cen[0]-slit[0]:cen[0]+slit[0]+1, self.pilatus.bglcen-slit[1]:self.pilatus.bgrcen+slit[1]+1])
                self.vmin=np.max(self.pilatus.imageData[cen[0]-slit[0]:cen[0]+slit[0]+1, self.pilatus.bglcen-slit[1]:self.pilatus.bgrcen+slit[1]+1])
                self.refZdata=self.pilatus.imageData
                p=self.ax[2].imshow(self.pilatus.imageROI[self.pilatus.bgucen-slit[0]:self.pilatus.bgdcen+slit[0]+1,cen[1]-slit[1]:cen[1]+slit[1]+1], origin='lower', aspect='auto', vmax=self.vmax, cmap=cmap, extent=self.refextent, interpolation='nearest')
                self.ax[2].set_ylabel('w Corr')
                self.ax[2].format_coord=self.format_coord_ref
        self.ui.refADDataPlotWidget.canvas.fig.colorbar(p)
        self.ui.refADDataPlotWidget.canvas.draw()
        self.fsig=sig-(lbg+rbg)/2.0
        self.fsigerr=np.sqrt(sigerr**2+(lbgerr**2+rbgerr**2)/4)
        self.fsigerrper=self.fsigerr/self.fsig*100.0
        self.ui.refQLineEdit.setText('%.4f'%float(str(self.refQzSelectedItems[0].text()).split()[1]))
        self.ui.refRLineEdit.setText('%.4e'%self.fsig)
        self.ui.refRErrLineEdit.setText('%.4e'%self.fsigerr)
        self.ui.refPerRErrLineEdit.setText('%.4f'%self.fsigerrper)
    
    def updateRefDataList(self):
        comments=str(self.refQzSelectedItems[0].text()).split('\t')[1:]
        self.refData.append([float(str(self.refQzSelectedItems[0].text()).split()[1]),self.fsig,self.fsigerr])
        self.refInfo.append('#'+comments[0]+'\t'+comments[1]+'\t#Comments:'+str(self.ui.refComLineEdit.text()))
        self.ui.refDataListWidget.addItem('%.4f'%float(str(self.refQzSelectedItems[0].text()).split()[1])+'\t'+'%.4e'%self.fsig+'\t'+'%.4e'%self.fsigerr+'\t'+self.refInfo[-1])
        self.updateRefPlotData()
        
    def refAnalyzeAll(self):
        self.refAnalyze()
        self.updateRefDataList()
        self.progressDialog=QProgressDialog('Analyzing Images for reflectivity calculations','Abort',1,self.ui.refQzListWidget.count())
        self.progressDialog.setWindowModality(Qt.WindowModal)
        self.progressDialog.setWindowTitle('Wait')
        self.progressDialog.setAutoClose(True)
        self.progressDialog.setAutoReset(True)
        self.progressDialog.setMinimum(1)
        self.progressDialog.setMaximum(self.ui.refQzListWidget.count())
        self.progressDialog.show()
        for i in range(1,self.ui.refQzListWidget.count()):
            self.disconnect(self.ui.refQzListWidget, SIGNAL('itemSelectionChanged()'),self.refQzListSelectionChanged)
            self.ui.refQzListWidget.setItemSelected(self.ui.refQzListWidget.item(i-1),False)
            self.connect(self.ui.refQzListWidget, SIGNAL('itemSelectionChanged()'),self.refQzListSelectionChanged)
            self.ui.refQzListWidget.setItemSelected(self.ui.refQzListWidget.item(i),True)
            self.refAnalyze()
            self.updateRefDataList()
            self.progressDialog.setLabelText('Reading Frames for Qz= '+str(self.refQzSelected))     
            self.updateProgress()
            if self.progressDialog.wasCanceled()==True:
                break
        self.progressDialog.hide()
            
            
        
    def delRefDataList(self):
        items=self.ui.refDataListWidget.selectedItems()
        for item in items:
            self.refData.pop(self.ui.refDataListWidget.row(item))
            self.refInfo.pop(self.ui.refDataListWidget.row(item))
            self.ui.refDataListWidget.takeItem(self.ui.refDataListWidget.row(item))
        self.updateRefPlotData()
        
    def fresnel(self,q,qc):
        fre=[]
        for qx in q:
            if qx<qc:
                fre.append(1)
            else:
                fre.append(((qx-np.sqrt(qx**2-qc**2))/(qx+np.sqrt(qx**2-qc**2)))**2)
        return np.array(fre)
    
    def addRefFiles(self):
        f=QFileDialog.getOpenFileNames(caption='Select Multiple Files to import', directory=self.directory, filter='Ref Files (*.ref)')
        self.reffiles=self.reffiles+map(str, f)
        self.reffnames=[]
        self.ui.refRefFileListWidget.clear()
        for i in range(len(self.reffiles)):
            s=str(self.reffiles[i])
            self.reffnames.append(s[s.rfind('/')+1:])
            self.ui.refRefFileListWidget.addItem('#'+str(i+1)+'\t'+self.reffnames[i])

    def removeRefFiles(self):
        items=self.ui.refRefFileListWidget.selectedItems()
        for item in items:
            self.reffnames.pop(self.ui.refRefFileListWidget.row(item))
            self.reffiles.pop(self.ui.refRefFileListWidget.row(item))
            #self.ui.refRefFileListWidget.takeItem(self.ui.refRefFileListWidget.row(item))
        self.ui.refRefFileListWidget.clear()
        for i in range(len(self.reffnames)):
            self.ui.refRefFileListWidget.addItem('#'+str(i+1)+'\t'+self.reffnames[i])
    
    def updateSelectedRefFiles(self):
        selectedreffiles=self.ui.refRefFileListWidget.selectedItems()
        self.selectedreffiles_rows=[]
        for item in selectedreffiles:
            self.selectedreffiles_rows.append(self.ui.refRefFileListWidget.row(item))
        self.updateRefPlotData()

        
    def updateRefPlotData(self):
        self.ui.refRefDataPlotwidget.canvas.ax.clear()
        self.ui.refNormRefListWidget.clear()
        self.ui.refRefDataPlotwidget.canvas.ax.set_xlabel('Qz')
        self.ui.refRefDataPlotwidget.canvas.ax.set_ylabel('R')
        self.refQc=float(self.ui.refQcLineEdit.text())
        self.refQoff=float(self.ui.refQoffLineEdit.text())
        try:
            data=np.array(self.refData)
            self.refInfoNew=[self.refInfo[i] for i in np.argsort(data[:,0])]
            data=data[np.argsort(data[:,0])]
            if data[0,0]<0.001:
                norm=data[0,1]
                normerr=data[0,2]
                data[:,1]=data[:,1]/norm
                data[:,2]=np.sqrt(data[:,2]**2/norm**2+normerr**2*data[:,1]**2/norm**4)
                perErr=data[:,2]*100.0/data[:,1]
                self.ui.refNormRefListWidget.addItem('Q\tRef\tRef_Err\t%Err\t#S')
                for i in range(len(data[:,0])):
                    self.ui.refNormRefListWidget.addItem('%.4f'%data[i,0]+'\t'+'%.4e'%data[i,1]+'\t'+'%.4e'%data[i,2]+'\t'+'%.4f'%perErr[i]+'\t'+self.refInfoNew[i])
            if self.ui.refNormFacCheckBox.checkState()>0:
                norm=float(self.ui.refNormLineEdit.text())
                normerr=np.sqrt(norm)
                data[:,1]=data[:,1]/norm
                data[:,2]=np.sqrt(data[:,2]**2/norm**2+normerr**2*data[:,1]**2/norm**4)
                perErr=data[:,2]*100.0/data[:,1]
                self.ui.refNormRefListWidget.addItem('Q\tRef\tRef_Err\t%Err\t#S')
                for i in range(len(data[:,0])):
                    self.ui.refNormRefListWidget.addItem('%.4f'%data[i,0]+'\t'+'%.4e'%data[i,1]+'\t'+'%.4e'%data[i,2]+'\t'+'%.4f'%perErr[i]+'\t'+self.refInfoNew[i])
            self.normRefData=data[np.argsort(data[:,0])]
            if self.ui.refRRFCheckBox.checkState()!=0:
                self.ui.refRefDataPlotwidget.canvas.ax.set_ylabel('R/RF')
                data[:,0]=data[:,0]+self.refQoff
                data[:,1]=data[:,1]/self.fresnel(data[:,0],self.refQc)
                data[:,2]=data[:,2]/self.fresnel(data[:,0],self.refQc)
            if self.ui.refQzSqrCheckBox.checkState()!=0:
                self.ui.refRefDataPlotwidget.canvas.ax.set_xlabel('Qz^2')
                data[:,0]=data[:,0]**2
            self.ui.refRefDataPlotwidget.canvas.ax.errorbar(data[:,0],data[:,1],data[:,2],fmt='o',label='#0')
        except:
            print 'no current ref data to plot'
     #plot selected ref files
        if  len(self.selectedreffiles_rows)!=0:
            for i in range(len(self.selectedreffiles_rows)):
                data1=np.loadtxt(str(self.reffiles[self.selectedreffiles_rows[i]]), comments='#')
                if self.ui.refRRFCheckBox.checkState()!=0:
                    self.ui.refRefDataPlotwidget.canvas.ax.set_ylabel('R/RF')
                    data1[:,0]=data1[:,0]+self.refQoff
                    data1[:,1]=data1[:,1]/self.fresnel(data1[:,0],self.refQc)
                    data1[:,2]=data1[:,2]/self.fresnel(data1[:,0],self.refQc)
                if self.ui.refQzSqrCheckBox.checkState()!=0:
                    self.ui.refRefDataPlotwidget.canvas.ax.set_xlabel('Qz^2')
                    data1[:,0]=data1[:,0]**2
                self.ui.refRefDataPlotwidget.canvas.ax.errorbar(data1[:,0],data1[:,1],data1[:,2],fmt='o',label='#'+str(self.selectedreffiles_rows[i]+1))
        # done
        if self.ui.refLogYCheckBox.checkState()!=0:
            self.ui.refRefDataPlotwidget.canvas.ax.set_yscale('log')
        else:
            self.ui.refRefDataPlotwidget.canvas.ax.set_yscale('linear')
        if self.ui.refLegendCheckBox.checkState()!=0:
            self.ui.refRefDataPlotwidget.canvas.ax.legend(loc=self.ui.refLegendLocComboBox.currentIndex()+1,frameon=False,scatterpoints=0,numpoints=1)
        self.ui.refRefDataPlotwidget.canvas.draw()
        self.saveTemData()
        
    def saveRefData(self):
        self.saveFileName=str(QFileDialog.getSaveFileName(caption='Save Reflectivity',directory=self.directory))
        fid=open(self.saveFileName+'.ref','w')
        for i in range(len(self.refInfo)):
            fid.write(str(self.normRefData[i,0])+'\t'+str(self.normRefData[i,1])+'\t'+str(self.normRefData[i,2])+'\t'+self.refInfoNew[i]+'\n')
        fid.close()
    
    def saveTemData(self):
        fid=open(self.directory+'/temp.ref','w')
        for i in range(len(self.refInfo)):
            fid.write(str(self.normRefData[i,0])+'\t'+str(self.normRefData[i,1])+'\t'+str(self.normRefData[i,2])+'\t'+self.refInfoNew[i]+'\n')
        fid.close()
    
    def clearCutGraph(self):
        self.ui.cutPlotMplWidget.canvas.ax.clear()
        self.ui.cutPlotMplWidget.canvas.draw()
        
    def updateCutData(self):
        if self.det=='Bruker':
            self.updateCcdCutData()
        elif self.det=='Pilatus':
            if self.pilGIDshow==0:
                self.updatePilCutData()
            else:
                self.updatePilGIDCutData()
        
    def updateCcdCutData(self):        
        self.selCutCcdData={}
        self.selCutCcdErrorData={}
        self.cutData={}
        self.cutLabel={}
        ini=float(str(self.ui.gixIntRangeLineEdit.text()).split(':')[0])
        fin=float(str(self.ui.gixIntRangeLineEdit.text()).split(':')[1])
        for i in self.selectedCcdFramesNums:
            self.selCutCcdData[i]=self.ccdData[i]#np.where(self.ccdData[i]<0,0,self.ccdData[i])#*self.absfac**self.ccd_AbsNum[i]/self.ccdMonc[i]
            self.selCutCcdErrorData[i]=self.ccdErrorData[i]#np.sqrt(self.ccdErrorData[i]**2/self.ccdMonc[i]**2+self.ccdData[i]**2/self.ccdMonc[i]**3)*self.absfac**self.ccd_AbsNum[i]
        if self.ui.gixSumCheckBox.checkState()!=0:
            self.selCutCcdData[-1]=self.selCutCcdData[self.selectedCcdFramesNums[0]]
            self.selCutCcdErrorData[-1]=self.selCutCcdErrorData[self.selectedCcdFramesNums[0]]
            for i in self.selectedCcdFramesNums[1:]:
                self.selCutCcdData[-1]=self.selCutCcdData[-1]+self.selCutCcdData[i]
                self.selCutCcdErrorData[-1]=self.selCutCcdErrorData[-1]+self.selCutCcdErrorData[i]**2
            self.selCutCcdData[-1]=self.selCutCcdData[-1]/len(self.selectedCcdFramesNums)
            self.selCutCcdErrorData[-1]=np.sqrt(self.selCutCcdErrorData[-1])/len(self.selectedCcdFramesNums)
            if self.ui.gixCutDirComboBox.currentText()=='H Cut':
                self.bruker.plotVint(self.selCutCcdData[-1],self.selCutCcdErrorData[-1],absfac=self.absfac,absnum=self.ccdSelected_AbsNum[0],cen=[self.xcenter[0]-self.xoff[0],self.ycenter[0]-self.yoff[0]],  hroi=None,  vroi=[int(ini)-1, int(fin)-1], ax_type=str(self.ui.gixAxesComboBox.currentText()), wavelength=self.wavelength[0],s2d_dist=self.distance[0],sh=self.ccdSelected_Sh[0],alpha=self.alpha[0], mon=None)
                self.cutData[-1]=self.bruker.vintData
            elif self.ui.gixCutDirComboBox.currentText()=='Qz Cut':
                ini=-int((self.distance[0]*np.arcsin(ini*self.wavelength[0]/2.0/np.pi-np.sin(self.alpha[0]))+self.ccdSelected_Sh[0])/0.06)+self.ycenter[0]-self.yoff[0]
                fin=-int((self.distance[0]*np.arcsin(fin*self.wavelength[0]/2.0/np.pi-np.sin(self.alpha[0]))+self.ccdSelected_Sh[0])/0.06)+self.ycenter[0]-self.yoff[0]                
                self.bruker.plotVint(self.selCutCcdData[-1],self.selCutCcdErrorData[-1],absfac=self.absfac,absnum=self.ccdSelected_AbsNum[0], cen=[self.xcenter[0]-self.xoff[0],self.ycenter[0]-self.yoff[0]],  hroi=None,  vroi=[fin-1, ini-1], ax_type='Q', wavelength=self.wavelength[0],s2d_dist=self.distance[0],sh=self.ccdSelected_Sh[0],alpha=self.alpha[0], mon=None)
                self.cutData[-1]=self.bruker.vintData
            elif self.ui.gixCutDirComboBox.currentText()=='V Cut':
                self.bruker.plotHint(self.selCutCcdData[-1],self.selCutCcdErrorData[-1],absfac=self.absfac,absnum=self.ccdSelected_AbsNum[0],cen=[self.xcenter[0]-self.xoff[0],self.ycenter[0]],  hroi=[int(ini)-1, int(fin)-1],  vroi=None, ax_type=str(self.ui.gixAxesComboBox.currentText()), wavelength=self.wavelength[0],s2d_dist=self.distance[0],sh=self.ccdSelected_Sh[0],alpha=self.alpha[0], mon=None)
                self.cutData[-1]=self.bruker.hintData
            else:
                ini=int(2.0*self.distance[0]*np.arcsin(ini*self.wavelength[0]/4.0/np.pi)/0.06)+self.xcenter[0]-self.xoff[0]
                fin=int(2.0*self.distance[0]*np.arcsin(fin*self.wavelength[0]/4.0/np.pi)/0.06)+self.xcenter[0]-self.xoff[0]
                self.bruker.plotHint(self.selCutCcdData[-1],self.selCutCcdErrorData[-1],absfac=self.absfac,absnum=self.ccdSelected_AbsNum[0],cen=[self.xcenter[0]-self.xoff[0],self.ycenter[0]-self.yoff[0]],  hroi=[int(ini)-1, int(fin)-1],  vroi=None, ax_type='Q', wavelength=self.wavelength[0],s2d_dist=self.distance[0],sh=self.ccdSelected_Sh[0],alpha=self.alpha[0], mon=None)
                self.cutData[-1]=self.bruker.hintData
            self.cutLabel[-1]='summed cuts'
        else:
            j=0
            for i in self.selectedCcdFramesNums:
                if self.ui.gixCutDirComboBox.currentText()=='H Cut':
                    self.bruker.plotVint(self.selCutCcdData[i],self.selCutCcdErrorData[i],absfac=self.absfac,absnum=self.ccdSelected_AbsNum[j], cen=[self.xcenter[j]-self.xoff[j],self.ycenter[j]-self.yoff[j]], hroi=None, vroi=[int(ini)-1, int(fin)-1], ax_type=str(self.ui.gixAxesComboBox.currentText()), wavelength=self.wavelength[j],s2d_dist=self.distance[j],sh=self.ccdSelected_Sh[j],alpha=self.alpha[j], mon=None)
                    self.cutData[i]=self.bruker.vintData
                elif self.ui.gixCutDirComboBox.currentText()=='Qz Cut':
                    ini1=-int((self.distance[j]*np.arcsin(ini*self.wavelength[j]/2.0/np.pi-np.sin(self.alpha[j]))+self.ccdSelected_Sh[j])/0.06)+self.ycenter[j]
                    fin1=-int((self.distance[j]*np.arcsin(fin*self.wavelength[j]/2.0/np.pi-np.sin(self.alpha[j]))+self.ccdSelected_Sh[j])/0.06)+self.ycenter[j]                
                    self.bruker.plotVint(self.selCutCcdData[i],self.selCutCcdErrorData[i],absfac=self.absfac,absnum=self.ccdSelected_AbsNum[j],cen=[self.xcenter[j]-self.xoff[j],self.ycenter[j]-self.yoff[j]],  hroi=None,  vroi=[fin1-1, ini1-1], ax_type='Q', wavelength=self.wavelength[j],s2d_dist=self.distance[j],sh=self.ccdSelected_Sh[j],alpha=self.alpha[j], mon=None)
                    self.cutData[i]=self.bruker.vintData    
                elif self.ui.gixCutDirComboBox.currentText()=='V Cut':
                    self.bruker.plotHint(self.selCutCcdData[i],self.selCutCcdErrorData[i],absfac=self.absfac,absnum=self.ccdSelected_AbsNum[j],cen=[self.xcenter[j]-self.xoff[j],self.ycenter[j]-self.yoff[j]], hroi=[int(ini)-1, int(fin)-1],  vroi=None, ax_type=str(self.ui.gixAxesComboBox.currentText()), wavelength=self.wavelength[j],s2d_dist=self.distance[j],sh=self.ccdSelected_Sh[j],alpha=self.alpha[j], mon=None)
                    self.cutData[i]=self.bruker.hintData
                else:
                    ini1=int(2.0*self.distance[j]*np.arcsin(ini*self.wavelength[j]/4.0/np.pi)/0.06)+self.xcenter[j]
                    fin1=int(2.0*self.distance[j]*np.arcsin(fin*self.wavelength[j]/4.0/np.pi)/0.06)+self.xcenter[j]
                    self.bruker.plotHint(self.selCutCcdData[i],self.selCutCcdErrorData[i],absfac=self.absfac,absnum=self.ccdSelected_AbsNum[j], cen=[self.xcenter[j]-self.xoff[j],self.ycenter[j]-self.yoff[j]], hroi=[ini1-1, fin1-1],  vroi=None, ax_type='Q', wavelength=self.wavelength[j],s2d_dist=self.distance[j],sh=self.ccdSelected_Sh[j],alpha=self.alpha[j], mon=None)
                    self.cutData[i]=self.bruker.hintData
                self.cutLabel[i]=str(self.ui.imageListWidget.item(i).text().split('\t')[0])+' '+str(self.ui.imageListWidget.item(i).text().split('\t')[1])
                j=j+1
        if self.ui.gixSumCheckBox.checkState()!=0:
            if self.ui.cutErrorbarCheckBox.checkState()!=0:
                self.ui.cutPlotMplWidget.canvas.ax.errorbar(self.cutData[-1][:,0],self.cutData[-1][:,1],self.cutData[-1][:,2],fmt='o-',label=self.cutLabel[-1])
            else:
                self.ui.cutPlotMplWidget.canvas.ax.plot(self.cutData[-1][:,0],self.cutData[-1][:,1],'o',label=self.cutLabel[-1])
                
        else:
            fact=1
            if self.ui.cutErrorbarCheckBox.checkState()!=0:
                for i in self.selectedCcdFramesNums:
                    self.ui.cutPlotMplWidget.canvas.ax.errorbar(self.cutData[i][:,0],fact*self.cutData[i][:,1],fact*self.cutData[i][:,2],fmt='o-',label=self.cutLabel[i])
                    if self.ui.cutOffsetCheckBox.checkState()!=0:
                        fact=fact*float(self.ui.cutOffsetLineEdit.text())
            else:      
                for i in self.selectedCcdFramesNums:
                    self.ui.cutPlotMplWidget.canvas.ax.plot(self.cutData[i][:,0],fact*self.cutData[i][:,1],'o',label=self.cutLabel[i])
                    if self.ui.cutOffsetCheckBox.checkState()!=0:
                        fact=fact*float(self.ui.cutOffsetLineEdit.text())
        self.updateCutPlotData()
        
    def updatePilCutData(self):        
        self.selCutPilData={}
        self.selCutPilErrorData={}
        self.cutData={}
        self.cutLabel={}
        ini=float(str(self.ui.pilIntRangeLineEdit.text()).split(':')[0])
        fin=float(str(self.ui.pilIntRangeLineEdit.text()).split(':')[1])
        for i in self.selectedPilFramesNums:
            self.selCutPilData[i]=self.pilData[i]#np.where(self.ccdData[i]<0,0,self.ccdData[i])#*self.absfac**self.ccd_AbsNum[i]/self.ccdMonc[i]
            self.selCutPilErrorData[i]=self.pilErrorData[i]#np.sqrt(self.ccdErrorData[i]**2/self.ccdMonc[i]**2+self.ccdData[i]**2/self.ccdMonc[i]**3)*self.absfac**self.ccd_AbsNum[i]
        if self.ui.gixSumCheckBox.checkState()!=0:
            self.selCutPilData[-1]=self.selCutPilData[self.selectedPilFramesNums[0]]
            self.selCutPilErrorData[-1]=self.selCutPilErrorData[self.selectedPilFramesNums[0]]
            for i in self.selectedPilFramesNums[1:]:
                self.selCutPilData[-1]=self.selCutPilData[-1]+self.selCutPilData[i]
                self.selCutPilErrorData[-1]=self.selCutPilErrorData[-1]+self.selCutPilErrorData[i]**2
            self.selCutPilData[-1]=self.selCutPilData[-1]/len(self.selectedPilFramesNums)
            self.selCutPilErrorData[-1]=np.sqrt(self.selCutPilErrorData[-1])/len(self.selectedPilFramesNums)
            if self.ui.pilCutDirComboBox.currentText()=='H Cut':
                self.pilatus.plotVint(self.selCutPilData[-1],self.selCutPilErrorData[-1],absfac=self.absfac,absnum=self.pilSelected_AbsNum[0],cen=[self.xcenter[0],self.ycenter[0]],  hroi=None,  vroi=[int(ini)-1, int(fin)-1], ax_type=str(self.ui.pilAxesComboBox.currentText()), wavelength=self.wavelength[0],s2d_dist=self.distance[0],sh=self.pilSelected_Sh[0],alpha=self.alpha[0], mon=None)
                self.cutData[-1]=self.pilatus.vintData
            elif self.ui.pilCutDirComboBox.currentText()=='Qz Cut':
                ini=-int((self.distance[0]*np.arcsin(ini*self.wavelength[0]/2.0/np.pi-np.sin(self.alpha[0]))+self.pilSelected_Sh[0])/0.172)+self.ycenter[0]
                fin=-int((self.distance[0]*np.arcsin(fin*self.wavelength[0]/2.0/np.pi-np.sin(self.alpha[0]))+self.pilSelected_Sh[0])/0.172)+self.ycenter[0]                
                self.pilatus.plotVint(self.selCutPilData[-1],self.selCutPilErrorData[-1],absfac=self.absfac,absnum=self.pilSelected_AbsNum[0], cen=[self.xcenter[0],self.ycenter[0]],  hroi=None,  vroi=[fin-1, ini-1], ax_type='Q', wavelength=self.wavelength[0],s2d_dist=self.distance[0],sh=self.pilSelected_Sh[0],alpha=self.alpha[0], mon=None)
                self.cutData[-1]=self.pilatus.vintData
            elif self.ui.pilCutDirComboBox.currentText()=='V Cut':
                self.pilatus.plotHint(self.selCutPilData[-1],self.selCutPilErrorData[-1],absfac=self.absfac,absnum=self.pilSelected_AbsNum[0],cen=[self.xcenter[0],self.ycenter[0]],  hroi=[int(ini)-1, int(fin)-1],  vroi=None, ax_type=str(self.ui.pilAxesComboBox.currentText()), wavelength=self.wavelength[0],s2d_dist=self.distance[0],sh=self.pilSelected_Sh[0],alpha=self.alpha[0], mon=None)
                self.cutData[-1]=self.pilatus.hintData
            else:
                ini=int(2.0*self.distance[0]*np.arcsin(ini*self.wavelength[0]/4.0/np.pi)/0.172)+self.xcenter[0]
                fin=int(2.0*self.distance[0]*np.arcsin(fin*self.wavelength[0]/4.0/np.pi)/0.172)+self.xcenter[0]
                self.pilatus.plotHint(self.selCutPilData[-1],self.selCutPilErrorData[-1],absfac=self.absfac,absnum=self.pilSelected_AbsNum[0],cen=[self.xcenter[0],self.ycenter[0]],  hroi=[int(ini)-1, int(fin)-1],  vroi=None, ax_type='Q', wavelength=self.wavelength[0],s2d_dist=self.distance[0],sh=self.pilSelected_Sh[0],alpha=self.alpha[0], mon=None)
                self.cutData[-1]=self.pilatus.hintData
            self.cutLabel[-1]='summed cuts'
        else:
            j=0
            for i in self.selectedPilFramesNums:
                if self.ui.pilCutDirComboBox.currentText()=='H Cut':
                    self.pilatus.plotVint(self.selCutPilData[i],self.selCutPilErrorData[i],absfac=self.absfac,absnum=self.pilSelected_AbsNum[j], cen=[self.xcenter[j],self.ycenter[j]], hroi=None, vroi=[int(ini)-1, int(fin)-1], ax_type=str(self.ui.pilAxesComboBox.currentText()), wavelength=self.wavelength[j],s2d_dist=self.distance[j],sh=self.pilSelected_Sh[j],alpha=self.alpha[j], mon=None)
                    self.cutData[i]=self.pilatus.vintData
                elif self.ui.pilCutDirComboBox.currentText()=='Qz Cut':
                    ini1=-int((self.distance[j]*np.arcsin(ini*self.wavelength[j]/2.0/np.pi-np.sin(self.alpha[j]))+self.pilSelected_Sh[j])/0.172)+self.ycenter[j]
                    fin1=-int((self.distance[j]*np.arcsin(fin*self.wavelength[j]/2.0/np.pi-np.sin(self.alpha[j]))+self.pilSelected_Sh[j])/0.172)+self.ycenter[j]                
                    self.pilatus.plotVint(self.selCutPilData[i],self.selCutPilErrorData[i],absfac=self.absfac,absnum=self.pilSelected_AbsNum[j],cen=[self.xcenter[j],self.ycenter[j]],  hroi=None,  vroi=[fin1-1, ini1-1], ax_type='Q', wavelength=self.wavelength[j],s2d_dist=self.distance[j],sh=self.pilSelected_Sh[j],alpha=self.alpha[j], mon=None)
                    self.cutData[i]=self.pilatus.vintData    
                elif self.ui.pilCutDirComboBox.currentText()=='V Cut':
                    self.pilatus.plotHint(self.selCutPilData[i],self.selCutPilErrorData[i],absfac=self.absfac,absnum=self.pilSelected_AbsNum[j],cen=[self.xcenter[j],self.ycenter[j]], hroi=[int(ini)-1, int(fin)-1],  vroi=None, ax_type=str(self.ui.pilAxesComboBox.currentText()), wavelength=self.wavelength[j],s2d_dist=self.distance[j],sh=self.pilSelected_Sh[j],alpha=self.alpha[j], mon=None)
                    self.cutData[i]=self.pilatus.hintData
                else:
                    ini1=int(2.0*self.distance[j]*np.arcsin(ini*self.wavelength[j]/4.0/np.pi)/0.172)+self.xcenter[j]
                    fin1=int(2.0*self.distance[j]*np.arcsin(fin*self.wavelength[j]/4.0/np.pi)/0.172)+self.xcenter[j]
                    self.pilatus.plotHint(self.selCutPilData[i],self.selCutPilErrorData[i],absfac=self.absfac,absnum=self.pilSelected_AbsNum[j], cen=[self.xcenter[j],self.ycenter[j]], hroi=[ini1-1, fin1-1],  vroi=None, ax_type='Q', wavelength=self.wavelength[j],s2d_dist=self.distance[j],sh=self.pilSelected_Sh[j],alpha=self.alpha[j], mon=None)
                    self.cutData[i]=self.pilatus.hintData
                self.cutLabel[i]=str(self.ui.imageListWidget.item(i).text().split('\t')[0])+' '+str(self.ui.imageListWidget.item(i).text().split('\t')[1])
                j=j+1
        if self.ui.gixSumCheckBox.checkState()!=0:
            if self.ui.cutErrorbarCheckBox.checkState()!=0:
                self.ui.cutPlotMplWidget.canvas.ax.errorbar(self.cutData[-1][:,0],self.cutData[-1][:,1],self.cutData[-1][:,2],fmt='o-',label=self.cutLabel[-1])
            else:
                self.ui.cutPlotMplWidget.canvas.ax.plot(self.cutData[-1][:,0],self.cutData[-1][:,1],'o',label=self.cutLabel[-1])
                
        else:
            fact=1
            if self.ui.cutErrorbarCheckBox.checkState()!=0:
                for i in self.selectedPilFramesNums:
                    self.ui.cutPlotMplWidget.canvas.ax.errorbar(self.cutData[i][:,0],fact*self.cutData[i][:,1],fact*self.cutData[i][:,2],fmt='o-',label=self.cutLabel[i])
                    if self.ui.cutOffsetCheckBox.checkState()!=0:
                        fact=fact*float(self.ui.cutOffsetLineEdit.text())
            else:      
                for i in self.selectedPilFramesNums:
                    self.ui.cutPlotMplWidget.canvas.ax.plot(self.cutData[i][:,0],fact*self.cutData[i][:,1],'o',label=self.cutLabel[i])
                    if self.ui.cutOffsetCheckBox.checkState()!=0:
                        fact=fact*float(self.ui.cutOffsetLineEdit.text())
        self.updateCutPlotData()
    
    def updatePilGIDCutData(self):
        self.pilhintData

    
    def updateCutPlotData(self):
        self.ui.PlotWidget.setCurrentIndex(4)
        self.cutLogX=self.ui.cutLogXCheckBox.checkState()
        self.cutLogY=self.ui.cutLogYCheckBox.checkState()
        self.cutGrid=self.ui.cutGridCheckBox.checkState()
        self.ui.cutPlotMplWidget.canvas.ax.set_xscale('linear')
        self.ui.cutPlotMplWidget.canvas.ax.set_yscale('linear')
        self.ui.cutPlotMplWidget.canvas.ax.set_ylabel('Intensity')
        self.ui.cutPlotMplWidget.canvas.ax.grid(b=False)
        if self.ui.gixCutDirComboBox.currentText()=='H Cut':
            self.ui.cutPlotMplWidget.canvas.ax.set_title('H Cut     Vint Range['+str(self.ui.gixIntRangeLineEdit.text())+']')
            self.ui.cutPlotMplWidget.canvas.ax.set_xlabel('Pixels')
        elif self.ui.gixCutDirComboBox.currentText()=='V Cut':
            self.ui.cutPlotMplWidget.canvas.ax.set_title('V Cut     Hint Range['+str(self.ui.gixIntRangeLineEdit.text())+']')
            self.ui.cutPlotMplWidget.canvas.ax.set_xlabel('Pixels')
        elif self.ui.gixCutDirComboBox.currentText()=='Qz Cut':
            self.ui.cutPlotMplWidget.canvas.ax.set_title('Qz Cut     Qz Range['+str(self.ui.gixIntRangeLineEdit.text())+']')
            self.ui.cutPlotMplWidget.canvas.ax.set_xlabel('Qxy (1/Angs)')
        else:
            self.ui.cutPlotMplWidget.canvas.ax.set_title('Qxy Cut     Qxy Range['+str(self.ui.gixIntRangeLineEdit.text())+']')
            self.ui.cutPlotMplWidget.canvas.ax.set_xlabel('Qz (1/Angs)')
        if self.cutLogX!=0:
            self.ui.cutPlotMplWidget.canvas.ax.set_xscale('log')
        if self.cutLogY!=0:
            self.ui.cutPlotMplWidget.canvas.ax.set_yscale('log')
        if self.cutGrid!=0:
            self.ui.cutPlotMplWidget.canvas.ax.grid(b=True,color='r',linestyle='--')
        if self.ui.cutLegendCheckBox.checkState()!=0:
            self.ui.cutPlotMplWidget.canvas.ax.legend(loc=self.ui.cutLegendLocComboBox.currentIndex()+1,frameon=False,scatterpoints=0,numpoints=1)
        self.ui.cutPlotMplWidget.canvas.draw()
        
    def saveCutData(self):
        self.saveFileName=str(QFileDialog.getSaveFileName(caption='Save Cuts'))
        if self.ui.gixSumCheckBox.checkState()!=0:
            self.fname=self.saveFileName+str(self.ui.imageListWidget.item(0).text().split('\t')[0])+'_sum.cut'
            np.savetxt(self.fname,self.cutData[-1],fmt='%.4f\t%.4e\t%.4e')
        else:
            for i in self.selectedCcdFramesNums:
                self.fname=self.saveFileName+str(self.ui.imageListWidget.item(i).text().split('\t')[0])+'_'+str(self.ui.imageListWidget.item(i).text().split('\t')[1])+'.cut'
                np.savetxt(self.fname,self.cutData[i],fmt='%.4f\t%.4e\t%.4e')
            
            
    def displayScanInfo(self):
        Dialog=QDialog(self)
        ui=uic.loadUi('scanInfoDialog.ui',Dialog)
        ui.show()
        snumtit=''
        for i in self.selectedScanNums:
            try:
                for j in range(self.specRead.Data['StartScanLineNums'][i],self.specRead.Data['StartScanLineNums'][i+1]):
                    snumtit=snumtit+self.specRead.SpecFileFull[j]
            except:
                for j in range(self.specRead.Data['StartScanLineNums'][i],len(self.specRead.SpecFileFull)):
                    snumtit=snumtit+self.specRead.SpecFileFull[j]
                
        ui.scanInfoTextBrowser.append(snumtit)
        Dialog.exec_()   
        
    def g_lfunction(self,par,x,y):
        return y-par[0]+par[1]*np.sin(x*np.pi/180)
        
    def calg_l2(self):
        Dialog=QDialog(self)
        self.uig_l2=uic.loadUi('g_l2Dialog.ui', Dialog)
        self.uig_l2.show()
        scannum=[item+1 for item in self.selectedScanNums]
        self.g_l2alpha=[self.specPar[i]['In_Rot'] for i in self.selectedScanNums]
        self.g_l2center=[self.scanCenter[i] for i in self.selectedScanNums]
        self.g_l2=[self.specPar[i]['g_l2'] for i in self.selectedScanNums]
        self.uig_l2.g_l2ScanLineEdit.setText(str(scannum)[1:-1])
        self.uig_l2.g_l2CenterLineEdit.setText(str(self.g_l2center)[1:-1])
        self.connect(self.uig_l2.g_l2CalPushButton,SIGNAL('clicked()'), self.g_l2plot)
        Dialog.exec_()
        
    def g_l2plot(self):
        self.uig_l2.g_l2TextBrowser.clear()
        if self.uig_l2.g_l2centercheckBox.checkState()!=0:
            self.g_l2center=map(float, str(self.uig_l2.g_l2CenterLineEdit.text()).split(','))
        par=[0,self.specPar[self.selectedScanNums[0]]['g_l2']]
        p=leastsq(self.g_lfunction,par,args=(np.array(self.g_l2alpha),np.array(self.g_l2center)),maxfev=5000)
        fp=p[0]
        self.uig_l2.g_l2plotWidget.canvas.ax.clear()
        self.uig_l2.g_l2plotWidget.canvas.ax.plot(self.g_l2alpha,self.g_l2center,'ro')
        self.uig_l2.g_l2plotWidget.canvas.ax.plot(np.array(self.g_l2alpha),fp[0]-fp[1]*np.sin(np.array(self.g_l2alpha)*np.pi/180),'-b',label=('g_l2= %.3f'%fp[1]))
        self.uig_l2.g_l2plotWidget.canvas.ax.set_xlabel('Alpha [Degrees]')
        self.uig_l2.g_l2plotWidget.canvas.ax.set_ylabel('Sh_Center [mm]')
        self.uig_l2.g_l2plotWidget.canvas.ax.legend(frameon=False,scatterpoints=0,numpoints=1)
        self.uig_l2.g_l2plotWidget.canvas.draw()
        self.uig_l2.g_l2TextBrowser.append(':Old Values:')
        self.uig_l2.g_l2TextBrowser.append('-----------------------------------------')
        self.uig_l2.g_l2TextBrowser.append('Scan \t Alpha \t Sh Nom \t Sh Cen \t N-C' )
        j=0
        for i in self.selectedScanNums:
            self.uig_l2.g_l2TextBrowser.append(str(i+1)+' \t %.4f '%self.g_l2alpha[j]+'\t %.4f'%(-np.sin(self.g_l2alpha[j]*np.pi/180)*self.g_l2[j])+'\t %.4f '%self.g_l2center[j]+'\t %.4f '%(-np.sin(self.g_l2alpha[j]*np.pi/180)*self.g_l2[j]-self.g_l2center[j]))
            j=j+1
        self.uig_l2.g_l2TextBrowser.append('\n')
        self.uig_l2.g_l2TextBrowser.append(':New Values:')
        self.uig_l2.g_l2TextBrowser.append('-----------------------------------------')
        self.uig_l2.g_l2TextBrowser.append('Scan \t Alpha \t Sh Nom \t Sh Cen \t N-C' )
        j=0
        for i in self.selectedScanNums:
            self.uig_l2.g_l2TextBrowser.append(str(i+1)+' \t %.4f '%self.g_l2alpha[j]+'\t %.4f'%(fp[0]-np.sin(self.g_l2alpha[j]*np.pi/180)*fp[1])+'\t %.4f '%self.g_l2center[j]+'\t %.4f '%(-np.sin(self.g_l2alpha[j]*np.pi/180)*fp[1]+fp[0]-self.g_l2center[j]))
            j=j+1
        self.uig_l2.g_l2TextBrowser.append('\n')
        self.uig_l2.g_l2TextBrowser.append('old g_l2\t= %.3f'%self.g_l2[0])
        self.uig_l2.g_l2TextBrowser.append('new g_l2\t= %.3f'%fp[1])
        self.uig_l2.g_l2TextBrowser.append('offset\t= %.3f'%fp[0])
        
    def calg_l3(self):
        Dialog=QDialog(self)
        self.uig_l3=uic.loadUi('g_l3Dialog.ui', Dialog)
        self.uig_l3.show()
        scannum=[item+1 for item in self.selectedScanNums]
        self.g_l3alpha=[self.specPar[i]['In_Rot'] for i in self.selectedScanNums]
        self.g_l3center=[self.scanCenter[i] for i in self.selectedScanNums]
        self.g_l3=[self.specPar[i]['g_l3'] for i in self.selectedScanNums]
        self.g_l2=[self.specPar[i]['g_l2'] for i in self.selectedScanNums]
        self.uig_l3.g_l3ScanLineEdit.setText(str(scannum)[1:-1])
        self.uig_l3.g_l3CenterLineEdit.setText(str(self.g_l3center)[1:-1])
        self.connect(self.uig_l3.g_l3CalPushButton,SIGNAL('clicked()'), self.g_l3plot)
        Dialog.exec_()
        
    def g_l3plot(self):
        self.uig_l3.g_l3TextBrowser.clear()
        if self.uig_l3.g_l3centercheckBox.checkState()!=0:
            self.g_l3center=map(float, str(self.uig_l3.g_l3CenterLineEdit.text()).split(','))
        par=[0,self.specPar[self.selectedScanNums[0]]['g_l2']-self.specPar[self.selectedScanNums[0]]['g_l3']]
        p=leastsq(self.g_lfunction,par,args=(np.array(self.g_l3alpha),np.array(self.g_l3center)),maxfev=5000)
        fp=p[0]
        self.uig_l3.g_l3plotWidget.canvas.ax.clear()
        self.uig_l3.g_l3plotWidget.canvas.ax.plot(self.g_l3alpha,self.g_l3center,'ro')
        self.uig_l3.g_l3plotWidget.canvas.ax.plot(np.array(self.g_l3alpha),fp[0]-fp[1]*np.sin(np.array(self.g_l3alpha)*np.pi/180),'-b',label=('g_l2-g_l3= %.3f'%fp[1]))
        self.uig_l3.g_l3plotWidget.canvas.ax.set_xlabel('Alpha [Degrees]')
        self.uig_l3.g_l3plotWidget.canvas.ax.set_ylabel('Oh_Center [mm]')
        self.uig_l3.g_l3plotWidget.canvas.ax.legend(frameon=False,scatterpoints=0,numpoints=1)
        self.uig_l3.g_l3plotWidget.canvas.draw()
        self.uig_l3.g_l3TextBrowser.append(':Old Values:')
        self.uig_l3.g_l3TextBrowser.append('-----------------------------------------')
        self.uig_l3.g_l3TextBrowser.append('Scan \t Alpha \t Oh Nom \t Oh Cen \t N-C' )
        j=0
        for i in self.selectedScanNums:
            self.uig_l3.g_l3TextBrowser.append(str(i+1)+' \t %.4f '%self.g_l3alpha[j]+'\t %.4f'%(np.sin(self.g_l3alpha[j]*np.pi/180)*(self.g_l3[j]-self.g_l2[j]))+'\t %.4f '%self.g_l3center[j]+'\t %.4f '%(np.sin(self.g_l3alpha[j]*np.pi/180)*(self.g_l3[j]-self.g_l2[j])-self.g_l3center[j]))
            j=j+1
        self.uig_l3.g_l3TextBrowser.append('\n')
        self.uig_l3.g_l3TextBrowser.append(':New Values:')
        self.uig_l3.g_l3TextBrowser.append('-----------------------------------------')
        self.uig_l3.g_l3TextBrowser.append('Scan \t Alpha \t Oh Nom \t Oh Cen \t N-C' )
        j=0
        for i in self.selectedScanNums:
            self.uig_l3.g_l3TextBrowser.append(str(i+1)+' \t %.4f '%self.g_l3alpha[j]+'\t %.4f'%(fp[0]-np.sin(self.g_l3alpha[j]*np.pi/180)*fp[1])+'\t %.4f '%self.g_l3center[j]+'\t %.4f '%(-np.sin(self.g_l3alpha[j]*np.pi/180)*fp[1]+fp[0]-self.g_l3center[j]))
            j=j+1
        self.uig_l3.g_l3TextBrowser.append('\n')
        self.uig_l3.g_l3TextBrowser.append('old (g_l2-g_l3)\t= %.3f'%(self.g_l2[0]-self.g_l3[0]))
        self.uig_l3.g_l3TextBrowser.append('new (g_l2_g_l3)\t= %.3f'%fp[1])
        self.uig_l3.g_l3TextBrowser.append('offset\t\t= %.3f'%fp[0])
    
    def absratiofunction(self,par,x,y):
        return y-np.log(par[0])+x*np.log(par[1])+par[2]*par[0]/par[1]**x
        #return y-par[0]/np.power(par[1],x)
        
    def calabsrat(self):
        scannum=self.selectedScanNums[0]
        if self.specData[scannum]['ScanVar'][0]!='Absorber':
            self.messageBox('Error:: This scan is NOT an absorber scan!!')
        else:
            Dialog=QDialog(self)
            uiabs=uic.loadUi('absratioDialog.ui', Dialog)
            uiabs.show()
            x=self.specData[scannum]['Absorber']
            z=self.specData[scannum]['Monc']
            ave=sum(z)/float(len(z))
            y=np.log(self.specData[scannum]['YAP']/z*ave/self.specData[scannum]['Seconds'])
            par=[1.0e+10,1.5,1.0e-8]
            #par=[1.0e+10,1.6]
            p=leastsq(self.absratiofunction,par,args=(x,y),maxfev=5000)
            fp=p[0]
            #print fp, y
            uiabs.absRatplotWidget.canvas.ax.clear()
            uiabs.absRatplotWidget.canvas.ax.plot(x,np.exp(y),'ro')
            uiabs.absRatplotWidget.canvas.ax.plot(x,fp[0]/fp[1]**x*np.exp(-fp[2]*par[0]/fp[1]**x),'-b')
            uiabs.absRatplotWidget.canvas.ax.set_xlabel('Absorber Number')
            uiabs.absRatplotWidget.canvas.ax.set_ylabel('Intensity')
            uiabs.absRatplotWidget.canvas.ax.set_yscale('log')
            uiabs.absRatplotWidget.canvas.draw()
            uiabs.absRatScanLineEdit.setText(str(scannum+1))
            uiabs.absRatAbsLineEdit.setText(str(fp[1]))
            uiabs.absRatSouLineEdit.setText('%.3e'%fp[0])
            uiabs.absRatDeaLineEdit.setText('%.3e'%fp[2])
            Dialog.exec_()
        
    def questionDialog(self, question='Do you want to continue?'):
        reply=QMessageBox.question(self, 'Message',
            question, QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        return reply
        
        